import { Outlet, NavLink, useLocation } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth'
import {
  LayoutDashboard, ShoppingCart, Package, Users, Truck,
  FileText, PackagePlus, ClipboardList, BarChart3,
  ArrowLeftRight, LogOut, ChevronRight, Zap
} from 'lucide-react'

const nav = [
  { label: 'Dashboard', to: '/', icon: LayoutDashboard, exact: true },
  { label: 'POS Terminal', to: '/pos', icon: ShoppingCart },
  { divider: 'INVENTORY' },
  { label: 'Products', to: '/products', icon: Package },
  { label: 'Stock Receipts', to: '/stock-receipts', icon: PackagePlus },
  { label: 'Stock Movements', to: '/stock-movements', icon: ArrowLeftRight },
  { divider: 'SALES' },
  { label: 'Invoices', to: '/invoices', icon: FileText },
  { label: 'Delivery Notes', to: '/delivery-notes', icon: Truck },
  { divider: 'MASTER DATA' },
  { label: 'Customers', to: '/customers', icon: Users },
  { label: 'Suppliers', to: '/suppliers', icon: ClipboardList },
  { divider: 'ANALYTICS' },
  { label: 'Reports', to: '/reports', icon: BarChart3 },
]

export default function Layout() {
  const { profile, signOut } = useAuth()
  const location = useLocation()

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: 'var(--bg)' }}>
      {/* Sidebar */}
      <aside className="w-60 flex flex-col flex-shrink-0 border-r" style={{ borderColor: 'var(--border)', background: 'var(--bg)' }}>
        {/* Logo */}
        <div className="px-5 py-5 flex items-center gap-3 border-b" style={{ borderColor: 'var(--border)' }}>
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--accent)' }}>
            <Zap size={16} color="#052e16" strokeWidth={2.5} />
          </div>
          <div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '1rem', color: 'var(--text)', letterSpacing: '-0.02em' }}>
              SWIFT POS
            </div>
            <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', fontFamily: 'Syne', letterSpacing: '0.1em' }}>
              POINT OF SALE
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
          {nav.map((item, i) => {
            if ('divider' in item) return (
              <div key={i} className="section-title pt-4 pb-1 px-2">{item.divider}</div>
            )
            const Icon = item.icon!
            const isActive = item.exact
              ? location.pathname === item.to
              : location.pathname.startsWith(item.to!)
            return (
              <NavLink
                key={item.to}
                to={item.to!}
                className={`sidebar-item ${isActive ? 'active' : ''}`}
              >
                <Icon size={16} strokeWidth={isActive ? 2.5 : 2} />
                <span className="flex-1">{item.label}</span>
                {isActive && <ChevronRight size={14} />}
              </NavLink>
            )
          })}
        </nav>

        {/* User footer */}
        <div className="px-3 py-3 border-t" style={{ borderColor: 'var(--border)' }}>
          <div className="flex items-center gap-3 px-2 py-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
              style={{ background: 'var(--accent-glow)', border: '1px solid var(--border-accent)', color: 'var(--accent)', fontFamily: 'Syne' }}>
              {profile?.full_name?.charAt(0)?.toUpperCase() ?? 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate" style={{ fontFamily: 'Syne' }}>{profile?.full_name ?? 'User'}</div>
              <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{profile?.role}</div>
            </div>
            <button onClick={signOut} className="p-1.5 rounded-lg transition-colors hover:bg-red-500/10" title="Sign out">
              <LogOut size={14} style={{ color: 'var(--text-muted)' }} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  )
}
