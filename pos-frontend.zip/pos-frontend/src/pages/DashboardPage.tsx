import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'
import { TrendingUp, ShoppingBag, AlertTriangle, Clock, ArrowUpRight, Package } from 'lucide-react'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { format, subDays } from 'date-fns'

interface DashStats {
  todayRevenue: number
  todayInvoices: number
  lowStockCount: number
  pendingInvoices: number
  recentInvoices: any[]
  lowStockProducts: any[]
  salesChart: { date: string; revenue: number }[]
}

const fmtZMW = (n: number) => `ZMW ${n.toLocaleString('en-ZM', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`

export default function DashboardPage() {
  const { profile } = useAuth()
  const [stats, setStats] = useState<DashStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadStats()
  }, [])

  const loadStats = async () => {
    const today = format(new Date(), 'yyyy-MM-dd')
    const sevenDaysAgo = format(subDays(new Date(), 6), 'yyyy-MM-dd')

    const [todayInv, lowStock, pending, recentInv, chartData] = await Promise.all([
      supabase.from('invoices').select('total_amount, id').eq('invoice_date', today).neq('status', 'cancelled').neq('status', 'void'),
      supabase.from('v_low_stock_products').select('*').limit(5),
      supabase.from('invoices').select('id').in('status', ['issued', 'partial', 'overdue']),
      supabase.from('v_invoice_summary').select('*').order('invoice_date', { ascending: false }).limit(6),
      supabase.from('v_daily_sales').select('sale_date, total_revenue').gte('sale_date', sevenDaysAgo).order('sale_date'),
    ])

    const todayRevenue = (todayInv.data ?? []).reduce((s: number, r: any) => s + (r.total_amount ?? 0), 0)

    const salesChart = chartData.data?.map((r: any) => ({
      date: format(new Date(r.sale_date), 'dd MMM'),
      revenue: r.total_revenue ?? 0,
    })) ?? []

    setStats({
      todayRevenue,
      todayInvoices: todayInv.data?.length ?? 0,
      lowStockCount: lowStock.data?.length ?? 0,
      pendingInvoices: pending.data?.length ?? 0,
      recentInvoices: recentInv.data ?? [],
      lowStockProducts: lowStock.data ?? [],
      salesChart,
    })
    setLoading(false)
  }

  const statusBadge = (status: string) => {
    const map: Record<string, string> = {
      draft: 'badge-gray', issued: 'badge-blue', paid: 'badge-green',
      partial: 'badge-yellow', overdue: 'badge-red', cancelled: 'badge-gray', void: 'badge-gray',
    }
    return <span className={`badge ${map[status] ?? 'badge-gray'}`}>{status}</span>
  }

  if (loading) return (
    <div className="p-8 flex items-center justify-center h-full">
      <div className="w-8 h-8 rounded-full border-2 border-transparent border-t-green-400 animate-spin" />
    </div>
  )

  return (
    <div className="p-6 space-y-6 max-w-7xl">
      {/* Header */}
      <div style={{ animation: 'fadeUp 0.3s ease-out both' }}>
        <h1 className="page-title">Dashboard</h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
          Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}, {profile?.full_name?.split(' ')[0]}
          <span style={{ color: 'var(--text-muted)' }}> — {format(new Date(), 'EEEE, d MMMM yyyy')}</span>
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 stagger">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem', fontFamily: 'Syne', letterSpacing: '0.05em', textTransform: 'uppercase' }}>Today's Revenue</span>
            <TrendingUp size={16} style={{ color: 'var(--accent)' }} />
          </div>
          <div className="text-amount text-2xl font-bold" style={{ color: 'var(--accent)' }}>{fmtZMW(stats?.todayRevenue ?? 0)}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>{stats?.todayInvoices} invoices today</div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem', fontFamily: 'Syne', letterSpacing: '0.05em', textTransform: 'uppercase' }}>Today's Sales</span>
            <ShoppingBag size={16} style={{ color: 'var(--info)' }} />
          </div>
          <div className="text-2xl font-bold" style={{ fontFamily: 'Syne', color: 'var(--info)' }}>{stats?.todayInvoices ?? 0}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>invoices raised</div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem', fontFamily: 'Syne', letterSpacing: '0.05em', textTransform: 'uppercase' }}>Low Stock</span>
            <AlertTriangle size={16} style={{ color: 'var(--warning)' }} />
          </div>
          <div className="text-2xl font-bold" style={{ fontFamily: 'Syne', color: stats?.lowStockCount ? 'var(--warning)' : 'var(--accent)' }}>{stats?.lowStockCount ?? 0}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>products need restocking</div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem', fontFamily: 'Syne', letterSpacing: '0.05em', textTransform: 'uppercase' }}>Outstanding</span>
            <Clock size={16} style={{ color: 'var(--danger)' }} />
          </div>
          <div className="text-2xl font-bold" style={{ fontFamily: 'Syne', color: stats?.pendingInvoices ? 'var(--danger)' : 'var(--accent)' }}>{stats?.pendingInvoices ?? 0}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>unpaid invoices</div>
        </div>
      </div>

      {/* Chart + Low stock */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4" style={{ animation: 'fadeUp 0.4s ease-out 0.15s both' }}>
        {/* Revenue chart */}
        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.95rem' }}>Revenue (Last 7 Days)</div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>Daily sales total in ZMW</div>
            </div>
          </div>
          {stats?.salesChart?.length ? (
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={stats.salesChart}>
                <defs>
                  <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fill: '#475569', fontSize: 11, fontFamily: 'DM Sans' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#475569', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} width={70}
                  tickFormatter={v => `${(v/1000).toFixed(0)}K`} />
                <Tooltip
                  contentStyle={{ background: '#1a1d27', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 8, fontFamily: 'DM Sans', fontSize: 12 }}
                  labelStyle={{ color: '#94a3b8' }}
                  itemStyle={{ color: '#22c55e' }}
                  formatter={(v: number) => [fmtZMW(v), 'Revenue']}
                />
                <Area type="monotone" dataKey="revenue" stroke="#22c55e" strokeWidth={2} fill="url(#rev)" dot={{ fill: '#22c55e', r: 3 }} activeDot={{ r: 5 }} />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-48" style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
              No sales data yet
            </div>
          )}
        </div>

        {/* Low stock */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <div style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.95rem' }}>Low Stock Alerts</div>
            <AlertTriangle size={15} style={{ color: 'var(--warning)' }} />
          </div>
          {stats?.lowStockProducts?.length ? (
            <div className="space-y-3">
              {stats.lowStockProducts.map((p: any) => (
                <div key={p.id} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.2)' }}>
                    <Package size={14} style={{ color: 'var(--warning)' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{p.name}</div>
                    <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{p.category}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-amount" style={{ color: 'var(--danger)' }}>{p.stock_quantity}</div>
                    <div className="text-xs" style={{ color: 'var(--text-muted)' }}>/ {p.reorder_level}</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-36 gap-2">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'rgba(34,197,94,0.1)' }}>
                <Package size={20} style={{ color: 'var(--accent)' }} />
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem', textAlign: 'center' }}>All stock levels look good</div>
            </div>
          )}
        </div>
      </div>

      {/* Recent invoices */}
      <div className="card" style={{ animation: 'fadeUp 0.4s ease-out 0.2s both' }}>
        <div className="px-5 py-4 flex items-center justify-between border-b" style={{ borderColor: 'var(--border)' }}>
          <div style={{ fontFamily: 'Syne', fontWeight: 600 }}>Recent Invoices</div>
          <a href="/invoices" className="flex items-center gap-1 text-xs" style={{ color: 'var(--accent)' }}>
            View all <ArrowUpRight size={12} />
          </a>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Invoice #', 'Customer', 'Date', 'Amount', 'Status'].map(h => (
                  <th key={h} className="px-5 py-3 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.75rem', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {stats?.recentInvoices?.length ? stats.recentInvoices.map((inv: any) => (
                <tr key={inv.id} className="table-row">
                  <td className="px-5 py-3 font-mono text-xs" style={{ color: 'var(--accent)' }}>{inv.invoice_number}</td>
                  <td className="px-5 py-3">{inv.customer_name ?? <span style={{ color: 'var(--text-muted)' }}>Walk-in</span>}</td>
                  <td className="px-5 py-3" style={{ color: 'var(--text-muted)' }}>{format(new Date(inv.invoice_date), 'dd MMM yyyy')}</td>
                  <td className="px-5 py-3 text-amount font-medium">{fmtZMW(inv.total_amount)}</td>
                  <td className="px-5 py-3">{statusBadge(inv.status)}</td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-5 py-8 text-center" style={{ color: 'var(--text-muted)' }}>No invoices yet</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
