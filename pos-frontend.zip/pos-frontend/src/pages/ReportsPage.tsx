import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { format, subDays, startOfMonth, endOfMonth } from 'date-fns'
import { BarChart3, TrendingUp, Package, Users, Download } from 'lucide-react'

const fmtZMW = (n: number) => `ZMW ${Number(n).toLocaleString('en-ZM', { minimumFractionDigits: 2 })}`
const PIE_COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4']

export default function ReportsPage() {
  const [period, setPeriod] = useState('month')
  const [salesData, setSalesData] = useState<any[]>([])
  const [topProducts, setTopProducts] = useState<any[]>([])
  const [stockValue, setStockValue] = useState(0)
  const [totalRevenue, setTotalRevenue] = useState(0)
  const [totalVat, setTotalVat] = useState(0)
  const [invoiceCount, setInvoiceCount] = useState(0)
  const [categoryData, setCategoryData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { load() }, [period])

  const getDateRange = () => {
    const now = new Date()
    if (period === 'today') return { from: format(now, 'yyyy-MM-dd'), to: format(now, 'yyyy-MM-dd') }
    if (period === 'week') return { from: format(subDays(now, 6), 'yyyy-MM-dd'), to: format(now, 'yyyy-MM-dd') }
    if (period === 'month') return { from: format(startOfMonth(now), 'yyyy-MM-dd'), to: format(endOfMonth(now), 'yyyy-MM-dd') }
    return { from: format(new Date(now.getFullYear(), 0, 1), 'yyyy-MM-dd'), to: format(now, 'yyyy-MM-dd') }
  }

  const load = async () => {
    setLoading(true)
    const { from, to } = getDateRange()

    const [daily, invs, prods, stockVal] = await Promise.all([
      supabase.from('v_daily_sales').select('*').gte('sale_date', from).lte('sale_date', to).order('sale_date'),
      supabase.from('invoices').select('id, total_amount, vat_amount, status').gte('invoice_date', from).lte('invoice_date', to).neq('status', 'cancelled').neq('status', 'void'),
      supabase.from('invoice_items').select('description, quantity, line_total, products(name, categories(name))').gte('created_at', from + 'T00:00:00').lte('created_at', to + 'T23:59:59'),
      supabase.from('products').select('cost_price, stock_quantity').eq('is_active', true),
    ])

    // Daily chart
    setSalesData((daily.data ?? []).map((r: any) => ({
      date: format(new Date(r.sale_date), period === 'year' ? 'MMM' : 'dd MMM'),
      revenue: r.total_revenue ?? 0,
      vat: r.total_vat ?? 0,
    })))

    // Summary
    const allInvs = invs.data ?? []
    setTotalRevenue(allInvs.reduce((s: number, i: any) => s + (i.total_amount ?? 0), 0))
    setTotalVat(allInvs.reduce((s: number, i: any) => s + (i.vat_amount ?? 0), 0))
    setInvoiceCount(allInvs.length)

    // Top products by revenue
    const prodMap: Record<string, { name: string; revenue: number; qty: number }> = {}
    for (const item of prods.data ?? []) {
      const name = (item.products as any)?.name ?? item.description
      if (!prodMap[name]) prodMap[name] = { name, revenue: 0, qty: 0 }
      prodMap[name].revenue += item.line_total ?? 0
      prodMap[name].qty += item.quantity ?? 0
    }
    setTopProducts(Object.values(prodMap).sort((a, b) => b.revenue - a.revenue).slice(0, 8))

    // Category breakdown
    const catMap: Record<string, number> = {}
    for (const item of prods.data ?? []) {
      const cat = (item.products as any)?.categories?.name ?? 'Uncategorised'
      catMap[cat] = (catMap[cat] ?? 0) + (item.line_total ?? 0)
    }
    setCategoryData(Object.entries(catMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value))

    // Stock value
    const sv = (stockVal.data ?? []).reduce((s: number, p: any) => s + (p.cost_price ?? 0) * (p.stock_quantity ?? 0), 0)
    setStockValue(sv)

    setLoading(false)
  }

  const periodBtns = [
    { key: 'today', label: 'Today' },
    { key: 'week', label: '7 Days' },
    { key: 'month', label: 'This Month' },
    { key: 'year', label: 'This Year' },
  ]

  const customTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null
    return (
      <div className="rounded-lg px-3 py-2 text-xs" style={{ background: '#1a1d27', border: '1px solid rgba(255,255,255,0.07)' }}>
        <div style={{ color: 'var(--text-muted)', marginBottom: 4 }}>{label}</div>
        {payload.map((p: any, i: number) => (
          <div key={i} style={{ color: p.color }}>{p.name}: {fmtZMW(p.value)}</div>
        ))}
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="page-title">Reports</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Financial and inventory analytics</p>
        </div>
        <div className="flex items-center gap-2">
          {periodBtns.map(b => (
            <button key={b.key} onClick={() => setPeriod(b.key)}
              className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={{
                background: period === b.key ? 'var(--accent)' : 'var(--bg-200)',
                color: period === b.key ? '#052e16' : 'var(--text-dim)',
                fontFamily: 'Syne',
                border: `1px solid ${period === b.key ? 'var(--accent)' : 'var(--border)'}`,
              }}>
              {b.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 stagger">
        {[
          { label: 'Revenue', value: fmtZMW(totalRevenue), icon: TrendingUp, color: 'var(--accent)', sub: `${invoiceCount} invoices` },
          { label: 'VAT Collected', value: fmtZMW(totalVat), icon: BarChart3, color: 'var(--info)', sub: 'ZRA VAT' },
          { label: 'Stock Value', value: fmtZMW(stockValue), icon: Package, color: 'var(--warning)', sub: 'at cost price' },
          { label: 'Invoices', value: invoiceCount.toString(), icon: Users, color: 'var(--danger)', sub: 'in period' },
        ].map(({ label, value, icon: Icon, color, sub }) => (
          <div key={label} className="stat-card">
            <div className="flex items-center justify-between">
              <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', fontFamily: 'Syne', letterSpacing: '0.05em', textTransform: 'uppercase' }}>{label}</span>
              <Icon size={15} style={{ color }} />
            </div>
            <div className="text-amount font-bold" style={{ color, fontSize: '1.1rem' }}>{value}</div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>{sub}</div>
          </div>
        ))}
      </div>

      {/* Revenue Chart */}
      <div className="card p-5" style={{ animation: 'fadeUp 0.4s ease-out 0.1s both' }}>
        <div className="mb-4">
          <div style={{ fontFamily: 'Syne', fontWeight: 600 }}>Revenue Trend</div>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>Daily sales and VAT breakdown</div>
        </div>
        {loading ? (
          <div className="flex items-center justify-center h-48"><div className="w-6 h-6 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>
        ) : salesData.length ? (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={salesData} barSize={period === 'today' ? 40 : 16}>
              <XAxis dataKey="date" tick={{ fill: '#475569', fontSize: 11, fontFamily: 'DM Sans' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#475569', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} width={72} tickFormatter={v => `${(v / 1000).toFixed(0)}K`} />
              <Tooltip content={customTooltip} />
              <Bar dataKey="revenue" name="Revenue" fill="#22c55e" radius={[4, 4, 0, 0]} />
              <Bar dataKey="vat" name="VAT" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex items-center justify-center h-48" style={{ color: 'var(--text-muted)' }}>No data for selected period</div>
        )}
      </div>

      {/* Top products + Category pie */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4" style={{ animation: 'fadeUp 0.4s ease-out 0.2s both' }}>
        {/* Top products */}
        <div className="card p-5">
          <div className="mb-4">
            <div style={{ fontFamily: 'Syne', fontWeight: 600 }}>Top Products by Revenue</div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>Best selling items in period</div>
          </div>
          {loading ? (
            <div className="flex items-center justify-center h-40"><div className="w-6 h-6 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>
          ) : topProducts.length ? (
            <div className="space-y-2.5">
              {topProducts.map((p, i) => {
                const maxRev = topProducts[0].revenue
                return (
                  <div key={p.name} className="flex items-center gap-3">
                    <div className="w-5 text-xs font-mono text-right flex-shrink-0" style={{ color: 'var(--text-muted)' }}>{i + 1}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm truncate" style={{ fontFamily: 'Syne' }}>{p.name}</span>
                        <span className="text-xs text-amount ml-2 flex-shrink-0" style={{ color: 'var(--accent)' }}>{fmtZMW(p.revenue)}</span>
                      </div>
                      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--bg-300)' }}>
                        <div className="h-full rounded-full" style={{ width: `${(p.revenue / maxRev) * 100}%`, background: 'var(--accent)', opacity: 0.7 + 0.3 * ((topProducts.length - i) / topProducts.length) }} />
                      </div>
                    </div>
                    <div className="text-xs flex-shrink-0" style={{ color: 'var(--text-muted)' }}>{p.qty} sold</div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="flex items-center justify-center h-40" style={{ color: 'var(--text-muted)' }}>No sales data</div>
          )}
        </div>

        {/* Category pie */}
        <div className="card p-5">
          <div className="mb-4">
            <div style={{ fontFamily: 'Syne', fontWeight: 600 }}>Revenue by Category</div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>Breakdown by product category</div>
          </div>
          {loading ? (
            <div className="flex items-center justify-center h-40"><div className="w-6 h-6 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>
          ) : categoryData.length ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={categoryData} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">
                  {categoryData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Legend formatter={(v) => <span style={{ fontSize: 11, color: 'var(--text-dim)', fontFamily: 'DM Sans' }}>{v}</span>} />
                <Tooltip formatter={(v: number) => fmtZMW(v)}
                  contentStyle={{ background: '#1a1d27', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-40" style={{ color: 'var(--text-muted)' }}>No data</div>
          )}
        </div>
      </div>
    </div>
  )
}
