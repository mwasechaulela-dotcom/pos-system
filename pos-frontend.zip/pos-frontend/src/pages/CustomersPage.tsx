import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Customer } from '@/types'
import { Plus, Search, Edit2, X, Loader2, CheckCircle2, Users } from 'lucide-react'

const empty = {
  name: '', contact_person: '', email: '', phone: '', address: '',
  tpin: '', credit_limit: 0, credit_days: 0, customer_type: 'retail', is_active: true, notes: ''
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Customer | null>(null)
  const [form, setForm] = useState<any>(empty)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState(false)

  useEffect(() => { load() }, [])

  const load = async () => {
    const { data } = await supabase.from('customers').select('*').order('name')
    setCustomers(data ?? [])
    setLoading(false)
  }

  const openAdd = () => { setEditing(null); setForm(empty); setShowModal(true) }
  const openEdit = (c: Customer) => { setEditing(c); setForm({ ...c }); setShowModal(true) }

  const save = async () => {
    setSaving(true)
    const payload = {
      ...form,
      credit_limit: parseFloat(form.credit_limit) || 0,
      credit_days: parseInt(form.credit_days) || 0,
    }
    if (editing) await supabase.from('customers').update(payload).eq('id', editing.id)
    else await supabase.from('customers').insert(payload)
    setSaving(false); setSuccess(true)
    setTimeout(() => setSuccess(false), 2000)
    setShowModal(false); load()
  }

  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.phone?.includes(search) || c.email?.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return <div className="flex items-center justify-center h-full"><div className="w-8 h-8 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>

  return (
    <div className="p-6 space-y-5 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Customers</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{customers.length} customers registered</p>
        </div>
        <button className="btn-primary" onClick={openAdd}><Plus size={16} />Add Customer</button>
      </div>

      <div className="relative max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
        <input className="input pl-9" placeholder="Search by name, phone, email..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Customer', 'Phone', 'Type', 'TPIN', 'Credit Limit', 'Status', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.72rem', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id} className="table-row">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold"
                        style={{ background: 'var(--accent-glow)', border: '1px solid var(--border-accent)', color: 'var(--accent)', fontFamily: 'Syne' }}>
                        {c.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium" style={{ fontFamily: 'Syne' }}>{c.name}</div>
                        {c.contact_person && <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{c.contact_person}</div>}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">{c.phone ?? '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`badge ${c.customer_type === 'credit' ? 'badge-yellow' : c.customer_type === 'wholesale' ? 'badge-blue' : 'badge-gray'}`}>
                      {c.customer_type}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--text-dim)' }}>{c.tpin ?? '—'}</td>
                  <td className="px-4 py-3 text-amount">ZMW {c.credit_limit.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <span className={`badge ${c.is_active ? 'badge-green' : 'badge-gray'}`}>{c.is_active ? 'Active' : 'Inactive'}</span>
                  </td>
                  <td className="px-4 py-3">
                    <button className="btn-secondary px-3 py-1.5 text-xs" onClick={() => openEdit(c)}><Edit2 size={12} />Edit</button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-12 text-center" style={{ color: 'var(--text-muted)' }}>
                  <Users size={32} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
                  No customers found
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
              <h2 style={{ fontFamily: 'Syne', fontWeight: 700 }}>{editing ? 'Edit Customer' : 'New Customer'}</h2>
              <button onClick={() => setShowModal(false)}><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><label className="label">Company / Customer Name *</label><input className="input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
                <div><label className="label">Contact Person</label><input className="input" value={form.contact_person} onChange={e => setForm({ ...form, contact_person: e.target.value })} /></div>
                <div><label className="label">Phone</label><input className="input" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
                <div><label className="label">Email</label><input className="input" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
                <div><label className="label">TPIN (ZRA)</label><input className="input" value={form.tpin} onChange={e => setForm({ ...form, tpin: e.target.value })} /></div>
                <div className="col-span-2"><label className="label">Address</label><textarea className="input resize-none" rows={2} value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
                <div>
                  <label className="label">Customer Type</label>
                  <select className="input" value={form.customer_type} onChange={e => setForm({ ...form, customer_type: e.target.value })}>
                    <option value="retail">Retail</option>
                    <option value="wholesale">Wholesale</option>
                    <option value="credit">Credit</option>
                  </select>
                </div>
                <div><label className="label">Credit Limit (ZMW)</label><input className="input text-amount" type="number" value={form.credit_limit} onChange={e => setForm({ ...form, credit_limit: e.target.value })} /></div>
                <div><label className="label">Credit Days</label><input className="input" type="number" value={form.credit_days} onChange={e => setForm({ ...form, credit_days: e.target.value })} /></div>
                <div className="flex items-center gap-3 pt-2">
                  <input type="checkbox" id="cActive" checked={form.is_active} onChange={e => setForm({ ...form, is_active: e.target.checked })} className="w-4 h-4" />
                  <label htmlFor="cActive" className="text-sm">Active customer</label>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t flex gap-3 justify-end" style={{ borderColor: 'var(--border)' }}>
              <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn-primary" onClick={save} disabled={saving || !form.name}>
                {saving ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />}
                {saving ? 'Saving...' : 'Save Customer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {success && (
        <div className="fixed bottom-6 right-6 flex items-center gap-3 px-5 py-4 rounded-xl"
          style={{ background: 'var(--bg-200)', border: '1px solid var(--border-accent)', boxShadow: '0 0 30px var(--accent-glow)', animation: 'slideUp 0.3s ease-out' }}>
          <CheckCircle2 size={18} style={{ color: 'var(--accent)' }} /><span style={{ fontFamily: 'Syne', fontWeight: 600 }}>Customer saved</span>
        </div>
      )}
    </div>
  )
}
