import { useEffect, useState, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'
import { Product, CartItem, Customer } from '@/types'
import { Search, Plus, Minus, Trash2, ShoppingCart, ChevronRight, X, Loader2, CheckCircle2, User } from 'lucide-react'

const fmtZMW = (n: number) => `ZMW ${n.toLocaleString('en-ZM', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`

function calcItem(item: CartItem): CartItem {
  const discounted = item.unit_price * item.quantity * (1 - item.discount_pct / 100)
  const vat = discounted * (item.vat_rate / 100)
  return { ...item, vat_amount: vat, line_total: discounted + vat }
}

export default function POSPage() {
  const { profile } = useAuth()
  const [products, setProducts] = useState<Product[]>([])
  const [cart, setCart] = useState<CartItem[]>([])
  const [search, setSearch] = useState('')
  const [customers, setCustomers] = useState<Customer[]>([])
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  const [customerSearch, setCustomerSearch] = useState('')
  const [paymentMethod, setPaymentMethod] = useState<string>('cash')
  const [amountTendered, setAmountTendered] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState<string | null>(null)
  const [showPayment, setShowPayment] = useState(false)
  const searchRef = useRef<HTMLInputElement>(null)

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    const [prods, custs] = await Promise.all([
      supabase.from('products').select('*, categories(name)').eq('is_active', true).gt('stock_quantity', 0).order('name'),
      supabase.from('customers').select('*').eq('is_active', true).order('name'),
    ])
    setProducts(prods.data ?? [])
    setCustomers(custs.data ?? [])
    setLoading(false)
  }

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.sku?.toLowerCase().includes(search.toLowerCase()) ||
    p.barcode?.includes(search)
  )

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(i => i.product.id === product.id)
      if (existing) {
        return prev.map(i => i.product.id === product.id
          ? calcItem({ ...i, quantity: i.quantity + 1 })
          : i)
      }
      return [...prev, calcItem({
        product,
        quantity: 1,
        unit_price: product.selling_price,
        discount_pct: 0,
        vat_rate: product.vat_rate,
        vat_amount: 0,
        line_total: 0,
      })]
    })
  }

  const updateQty = (productId: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.product.id !== productId) return i
      const newQty = i.quantity + delta
      if (newQty <= 0) return i
      return calcItem({ ...i, quantity: newQty })
    }))
  }

  const removeItem = (productId: string) => setCart(prev => prev.filter(i => i.product.id !== productId))

  const subtotal = cart.reduce((s, i) => s + i.line_total - i.vat_amount, 0)
  const totalVat = cart.reduce((s, i) => s + i.vat_amount, 0)
  const total = cart.reduce((s, i) => s + i.line_total, 0)
  const change = parseFloat(amountTendered || '0') - total

  const processInvoice = async () => {
    if (!cart.length) return
    setSaving(true)
    try {
      // Get doc number
      const { data: docNum } = await supabase.rpc('generate_document_number', { p_type: 'invoice' })

      // Create invoice
      const { data: inv, error: invErr } = await supabase.from('invoices').insert({
        invoice_number: docNum,
        customer_id: selectedCustomer?.id ?? null,
        created_by: profile?.id,
        status: 'draft',
        payment_method: paymentMethod,
        subtotal,
        vat_amount: totalVat,
        discount_amount: 0,
        total_amount: total,
        amount_paid: total,
      }).select().single()

      if (invErr) throw invErr

      // Create line items
      const items = cart.map(i => ({
        invoice_id: inv.id,
        product_id: i.product.id,
        description: i.product.name,
        quantity: i.quantity,
        unit_price: i.unit_price,
        discount_pct: i.discount_pct,
        vat_rate: i.vat_rate,
        vat_amount: i.vat_amount,
        line_total: i.line_total,
      }))

      const { error: itemsErr } = await supabase.from('invoice_items').insert(items)
      if (itemsErr) throw itemsErr

      // Process stock deduction
      await supabase.rpc('process_invoice_stock', { p_invoice_id: inv.id, p_user_id: profile?.id })

      setSuccess(docNum)
      setCart([])
      setSelectedCustomer(null)
      setAmountTendered('')
      setShowPayment(false)
      await loadData()
    } catch (err: any) {
      alert('Error: ' + err.message)
    } finally {
      setSaving(false)
    }
  }

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
    c.phone?.includes(customerSearch)
  )

  if (loading) return (
    <div className="flex items-center justify-center h-full">
      <div className="w-8 h-8 rounded-full border-2 border-transparent border-t-green-400 animate-spin" />
    </div>
  )

  return (
    <div className="flex h-full overflow-hidden" style={{ background: 'var(--bg)' }}>
      {/* Product grid */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <div className="px-6 py-4 border-b flex items-center gap-4" style={{ borderColor: 'var(--border)' }}>
          <h1 className="page-title">POS Terminal</h1>
          <div className="flex-1 relative max-w-md">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
            <input
              ref={searchRef}
              className="input pl-9"
              placeholder="Search by name, SKU, or barcode..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              autoFocus
            />
            {search && (
              <button className="absolute right-3 top-1/2 -translate-y-1/2" onClick={() => setSearch('')}>
                <X size={13} style={{ color: 'var(--text-muted)' }} />
              </button>
            )}
          </div>
        </div>

        {/* Products grid */}
        <div className="flex-1 overflow-y-auto p-5">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 gap-3">
              <Package size={32} style={{ color: 'var(--text-muted)' }} />
              <p style={{ color: 'var(--text-muted)' }}>No products found</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
              {filtered.map(p => (
                <div key={p.id} className="pos-product-card" onClick={() => addToCart(p)}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="text-xs px-1.5 py-0.5 rounded" style={{ background: 'var(--bg-300)', color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.65rem' }}>
                      {(p as any).categories?.name ?? 'General'}
                    </div>
                    <div className="text-xs font-mono" style={{ color: p.stock_quantity <= p.reorder_level ? 'var(--warning)' : 'var(--text-muted)' }}>
                      {p.stock_quantity} {p.unit_of_measure}
                    </div>
                  </div>
                  <div className="font-medium text-sm leading-tight mb-2" style={{ fontFamily: 'Syne' }}>{p.name}</div>
                  <div className="flex items-center justify-between">
                    <div className="text-amount font-bold" style={{ color: 'var(--accent)', fontSize: '0.9rem' }}>{fmtZMW(p.selling_price)}</div>
                    <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ background: 'var(--accent)' }}>
                      <Plus size={12} color="#052e16" strokeWidth={3} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Cart sidebar */}
      <div className="w-80 flex flex-col border-l" style={{ borderColor: 'var(--border)', background: 'var(--bg-100)' }}>
        {/* Customer selector */}
        <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border)' }}>
          <label className="label">Customer</label>
          {selectedCustomer ? (
            <div className="flex items-center gap-2 p-2 rounded-lg" style={{ background: 'var(--bg-200)', border: '1px solid var(--border-accent)' }}>
              <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: 'var(--accent-glow)', border: '1px solid var(--border-accent)' }}>
                <User size={13} style={{ color: 'var(--accent)' }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{selectedCustomer.name}</div>
                <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{selectedCustomer.customer_type}</div>
              </div>
              <button onClick={() => setSelectedCustomer(null)}>
                <X size={14} style={{ color: 'var(--text-muted)' }} />
              </button>
            </div>
          ) : (
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
              <input
                className="input pl-8 text-sm"
                placeholder="Walk-in / search customer..."
                value={customerSearch}
                onChange={e => setCustomerSearch(e.target.value)}
              />
              {customerSearch && filteredCustomers.length > 0 && (
                <div className="absolute z-10 left-0 right-0 top-full mt-1 rounded-lg overflow-hidden" style={{ background: 'var(--bg-200)', border: '1px solid var(--border)' }}>
                  {filteredCustomers.slice(0, 4).map(c => (
                    <div key={c.id} className="px-3 py-2 text-sm cursor-pointer hover:bg-[var(--bg-300)] transition-colors"
                      onClick={() => { setSelectedCustomer(c); setCustomerSearch('') }}>
                      <div>{c.name}</div>
                      <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{c.phone}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Cart header */}
        <div className="px-4 py-3 flex items-center justify-between border-b" style={{ borderColor: 'var(--border)' }}>
          <div className="flex items-center gap-2">
            <ShoppingCart size={15} style={{ color: 'var(--accent)' }} />
            <span style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.9rem' }}>Cart</span>
          </div>
          {cart.length > 0 && (
            <button className="text-xs" style={{ color: 'var(--danger)' }} onClick={() => setCart([])}>Clear all</button>
          )}
        </div>

        {/* Cart items */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 gap-2">
              <ShoppingCart size={28} style={{ color: 'var(--text-muted)' }} />
              <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', textAlign: 'center' }}>Add products to start a sale</p>
            </div>
          ) : cart.map(item => (
            <div key={item.product.id} className="rounded-lg p-3" style={{ background: 'var(--bg-200)', border: '1px solid var(--border)' }}>
              <div className="flex items-start justify-between mb-2">
                <div className="text-sm font-medium leading-tight flex-1 mr-2" style={{ fontFamily: 'Syne' }}>{item.product.name}</div>
                <button onClick={() => removeItem(item.product.id)}>
                  <Trash2 size={13} style={{ color: 'var(--text-muted)' }} />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button className="w-6 h-6 rounded-md flex items-center justify-center transition-colors"
                    style={{ background: 'var(--bg-300)' }} onClick={() => updateQty(item.product.id, -1)}>
                    <Minus size={11} />
                  </button>
                  <span className="text-sm font-mono w-6 text-center">{item.quantity}</span>
                  <button className="w-6 h-6 rounded-md flex items-center justify-center transition-colors"
                    style={{ background: 'var(--bg-300)' }} onClick={() => updateQty(item.product.id, 1)}>
                    <Plus size={11} />
                  </button>
                </div>
                <div className="text-amount text-sm font-medium" style={{ color: 'var(--accent)' }}>{fmtZMW(item.line_total)}</div>
              </div>
              <div className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>{fmtZMW(item.unit_price)} × {item.quantity}</div>
            </div>
          ))}
        </div>

        {/* Totals */}
        {cart.length > 0 && (
          <div className="px-4 py-3 border-t space-y-2" style={{ borderColor: 'var(--border)' }}>
            <div className="flex justify-between text-sm" style={{ color: 'var(--text-muted)' }}>
              <span>Subtotal</span><span className="text-amount">{fmtZMW(subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm" style={{ color: 'var(--text-muted)' }}>
              <span>VAT (16%)</span><span className="text-amount">{fmtZMW(totalVat)}</span>
            </div>
            <div className="flex justify-between font-bold text-base pt-1 border-t" style={{ borderColor: 'var(--border)', fontFamily: 'Syne' }}>
              <span>Total</span><span className="text-amount" style={{ color: 'var(--accent)' }}>{fmtZMW(total)}</span>
            </div>
          </div>
        )}

        {/* Checkout button */}
        <div className="px-4 py-3 border-t" style={{ borderColor: 'var(--border)' }}>
          <button
            className="btn-primary w-full justify-center py-3"
            disabled={!cart.length || saving}
            onClick={() => setShowPayment(true)}
          >
            <ChevronRight size={16} />
            Proceed to Payment
          </button>
        </div>
      </div>

      {/* Payment modal */}
      {showPayment && (
        <div className="modal-overlay" onClick={() => !saving && setShowPayment(false)}>
          <div className="modal-content w-full max-w-md" onClick={e => e.stopPropagation()}>
            <div className="px-6 py-5 border-b" style={{ borderColor: 'var(--border)' }}>
              <h2 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1.1rem' }}>Complete Payment</h2>
              <div className="text-2xl font-bold text-amount mt-1" style={{ color: 'var(--accent)' }}>{fmtZMW(total)}</div>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div>
                <label className="label">Payment Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {['cash', 'mobile_money', 'bank_transfer', 'cheque', 'credit', 'other'].map(pm => (
                    <button key={pm} onClick={() => setPaymentMethod(pm)}
                      className="px-2 py-2 rounded-lg text-xs font-medium capitalize transition-all"
                      style={{
                        background: paymentMethod === pm ? 'var(--accent)' : 'var(--bg-200)',
                        color: paymentMethod === pm ? '#052e16' : 'var(--text-dim)',
                        border: `1px solid ${paymentMethod === pm ? 'var(--accent)' : 'var(--border)'}`,
                        fontFamily: 'Syne',
                      }}>
                      {pm.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
              {paymentMethod === 'cash' && (
                <div>
                  <label className="label">Amount Tendered</label>
                  <input className="input text-amount" type="number" step="0.01" placeholder="0.00"
                    value={amountTendered} onChange={e => setAmountTendered(e.target.value)} />
                  {parseFloat(amountTendered) >= total && (
                    <div className="mt-2 flex justify-between text-sm">
                      <span style={{ color: 'var(--text-muted)' }}>Change</span>
                      <span className="text-amount font-bold" style={{ color: 'var(--accent)' }}>{fmtZMW(change)}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t flex gap-3" style={{ borderColor: 'var(--border)' }}>
              <button className="btn-secondary flex-1 justify-center" onClick={() => setShowPayment(false)} disabled={saving}>Cancel</button>
              <button className="btn-primary flex-1 justify-center" onClick={processInvoice} disabled={saving}>
                {saving ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />}
                {saving ? 'Processing...' : 'Confirm Sale'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success toast */}
      {success && (
        <div className="fixed bottom-6 right-6 flex items-center gap-3 px-5 py-4 rounded-xl shadow-2xl"
          style={{ background: 'var(--bg-200)', border: '1px solid var(--border-accent)', boxShadow: '0 0 30px var(--accent-glow)', animation: 'slideUp 0.3s ease-out' }}>
          <CheckCircle2 size={20} style={{ color: 'var(--accent)' }} />
          <div>
            <div style={{ fontFamily: 'Syne', fontWeight: 600 }}>Sale Complete</div>
            <div className="text-sm font-mono" style={{ color: 'var(--accent)' }}>{success}</div>
          </div>
          <button className="ml-2" onClick={() => setSuccess(null)}><X size={14} style={{ color: 'var(--text-muted)' }} /></button>
        </div>
      )}
    </div>
  )
}

function Package({ size, style }: { size: number, style?: any }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={style}>
      <path d="m16.5 9.4-9-5.19M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" x2="12" y1="22" y2="12"/>
    </svg>
  )
}
