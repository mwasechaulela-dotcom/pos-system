import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { StockReceipt, Supplier, Product } from '@/types'
import { Plus, Search, Eye, CheckCircle2, X, Loader2, Trash2, PackagePlus } from 'lucide-react'
import { format } from 'date-fns'
import { useAuth } from '@/hooks/useAuth'

const fmtZMW = (n: number) => `ZMW ${Number(n).toLocaleString('en-ZM', { minimumFractionDigits: 2 })}`

export default function StockReceiptsPage() {
  const { profile } = useAuth()
  const [receipts, setReceipts] = useState<StockReceipt[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [viewReceipt, setViewReceipt] = useState<any | null>(null)
  const [viewItems, setViewItems] = useState<any[]>([])
  const [saving, setSaving] = useState(false)
  const [confirming, setConfirming] = useState(false)

  // New GRN form state
  const [grnForm, setGrnForm] = useState({ supplier_id: '', receipt_date: format(new Date(), 'yyyy-MM-dd'), supplier_invoice_ref: '', notes: '' })
  const [lines, setLines] = useState<any[]>([{ product_id: '', description: '', quantity_ordered: '', quantity_received: '', unit_cost: '', vat_rate: '0' }])

  useEffect(() => { load() }, [])

  const load = async () => {
    const [rec, sup, prod] = await Promise.all([
      supabase.from('stock_receipts').select('*, suppliers(name), profiles(full_name)').order('created_at', { ascending: false }),
      supabase.from('suppliers').select('*').eq('is_active', true).order('name'),
      supabase.from('products').select('*').eq('is_active', true).order('name'),
    ])
    setReceipts(rec.data ?? [])
    setSuppliers(sup.data ?? [])
    setProducts(prod.data ?? [])
    setLoading(false)
  }

  const addLine = () => setLines(prev => [...prev, { product_id: '', description: '', quantity_ordered: '', quantity_received: '', unit_cost: '', vat_rate: '0' }])
  const removeLine = (i: number) => setLines(prev => prev.filter((_, idx) => idx !== i))

  const updateLine = (i: number, field: string, value: string) => {
    setLines(prev => prev.map((l, idx) => {
      if (idx !== i) return l
      const updated = { ...l, [field]: value }
      if (field === 'product_id' && value) {
        const prod = products.find(p => p.id === value)
        if (prod) { updated.description = prod.name; updated.unit_cost = String(prod.cost_price); updated.vat_rate = String(prod.vat_rate) }
      }
      return updated
    }))
  }

  const calcLine = (l: any) => {
    const qty = parseFloat(l.quantity_received) || 0
    const cost = parseFloat(l.unit_cost) || 0
    const vat = parseFloat(l.vat_rate) || 0
    const base = qty * cost
    const vatAmt = base * vat / 100
    return { base, vatAmt, total: base + vatAmt }
  }

  const totals = lines.reduce((acc, l) => {
    const c = calcLine(l)
    return { subtotal: acc.subtotal + c.base, vat: acc.vat + c.vatAmt, total: acc.total + c.total }
  }, { subtotal: 0, vat: 0, total: 0 })

  const saveGRN = async () => {
    setSaving(true)
    try {
      const docNum = (await supabase.rpc('generate_document_number', { p_type: 'grn' })).data
      const { data: grn, error } = await supabase.from('stock_receipts').insert({
        grn_number: docNum,
        supplier_id: grnForm.supplier_id || null,
        received_by: profile?.id,
        receipt_date: grnForm.receipt_date,
        supplier_invoice_ref: grnForm.supplier_invoice_ref || null,
        status: 'draft',
        subtotal: totals.subtotal,
        vat_amount: totals.vat,
        total_amount: totals.total,
        notes: grnForm.notes || null,
      }).select().single()
      if (error) throw error

      const items = lines.filter(l => l.quantity_received).map(l => {
        const c = calcLine(l)
        return {
          stock_receipt_id: grn.id,
          product_id: l.product_id || null,
          description: l.description,
          quantity_ordered: parseFloat(l.quantity_ordered) || 0,
          quantity_received: parseFloat(l.quantity_received),
          unit_cost: parseFloat(l.unit_cost),
          vat_rate: parseFloat(l.vat_rate) || 0,
          vat_amount: c.vatAmt,
          line_total: c.total,
        }
      })
      await supabase.from('stock_receipt_items').insert(items)
      setShowNew(false)
      setGrnForm({ supplier_id: '', receipt_date: format(new Date(), 'yyyy-MM-dd'), supplier_invoice_ref: '', notes: '' })
      setLines([{ product_id: '', description: '', quantity_ordered: '', quantity_received: '', unit_cost: '', vat_rate: '0' }])
      load()
    } catch (err: any) { alert('Error: ' + err.message) }
    setSaving(false)
  }

  const openView = async (r: StockReceipt) => {
    setViewReceipt(r)
    const { data } = await supabase.from('stock_receipt_items').select('*, products(name, sku)').eq('stock_receipt_id', r.id)
    setViewItems(data ?? [])
  }

  const confirmGRN = async () => {
    if (!viewReceipt) return
    setConfirming(true)
    try {
      await supabase.rpc('confirm_stock_receipt', { p_grn_id: viewReceipt.id, p_user_id: profile?.id })
      setViewReceipt(null)
      load()
    } catch (err: any) { alert('Error: ' + err.message) }
    setConfirming(false)
  }

  const filtered = receipts.filter(r =>
    r.grn_number?.toLowerCase().includes(search.toLowerCase()) ||
    (r as any).suppliers?.name?.toLowerCase().includes(search.toLowerCase())
  )

  const statusBadge = (s: string) => {
    const m: Record<string, string> = { draft: 'badge-yellow', confirmed: 'badge-green', cancelled: 'badge-gray' }
    return <span className={`badge ${m[s] ?? 'badge-gray'}`}>{s}</span>
  }

  if (loading) return <div className="flex items-center justify-center h-full"><div className="w-8 h-8 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>

  return (
    <div className="p-6 space-y-5 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Stock Receipts (GRN)</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{receipts.length} goods received notes</p>
        </div>
        <button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={16} />New GRN</button>
      </div>

      <div className="relative max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
        <input className="input pl-9" placeholder="Search GRN # or supplier..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['GRN #', 'Supplier', 'Date', 'Supplier Ref', 'Total', 'Status', 'Received By', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.72rem', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => (
                <tr key={r.id} className="table-row">
                  <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--accent)' }}>{r.grn_number}</td>
                  <td className="px-4 py-3" style={{ fontFamily: 'Syne' }}>{(r as any).suppliers?.name ?? '—'}</td>
                  <td className="px-4 py-3" style={{ color: 'var(--text-dim)' }}>{format(new Date(r.receipt_date), 'dd MMM yyyy')}</td>
                  <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--text-dim)' }}>{r.supplier_invoice_ref ?? '—'}</td>
                  <td className="px-4 py-3 text-amount font-medium">{fmtZMW(r.total_amount)}</td>
                  <td className="px-4 py-3">{statusBadge(r.status)}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'var(--text-dim)' }}>{(r as any).profiles?.full_name ?? '—'}</td>
                  <td className="px-4 py-3">
                    <button className="btn-secondary px-3 py-1.5 text-xs" onClick={() => openView(r)}><Eye size={12} />View</button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-12 text-center" style={{ color: 'var(--text-muted)' }}>
                  <PackagePlus size={32} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />No stock receipts yet
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New GRN Modal */}
      {showNew && (
        <div className="modal-overlay" onClick={() => setShowNew(false)}>
          <div className="modal-content max-w-3xl" onClick={e => e.stopPropagation()}>
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
              <h2 style={{ fontFamily: 'Syne', fontWeight: 700 }}>New Stock Receipt (GRN)</h2>
              <button onClick={() => setShowNew(false)}><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
            </div>
            <div className="px-6 py-5 space-y-5">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="label">Supplier</label>
                  <select className="input" value={grnForm.supplier_id} onChange={e => setGrnForm({ ...grnForm, supplier_id: e.target.value })}>
                    <option value="">Select supplier</option>
                    {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Receipt Date</label>
                  <input type="date" className="input" value={grnForm.receipt_date} onChange={e => setGrnForm({ ...grnForm, receipt_date: e.target.value })} />
                </div>
                <div>
                  <label className="label">Supplier Invoice Ref</label>
                  <input className="input" value={grnForm.supplier_invoice_ref} placeholder="SI-0001" onChange={e => setGrnForm({ ...grnForm, supplier_invoice_ref: e.target.value })} />
                </div>
              </div>

              {/* Line items */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.875rem' }}>Items Received</div>
                  <button className="btn-secondary text-xs px-3 py-1.5" onClick={addLine}><Plus size={12} />Add Line</button>
                </div>
                <div className="rounded-lg overflow-hidden" style={{ border: '1px solid var(--border)' }}>
                  <table className="w-full text-xs">
                    <thead style={{ background: 'var(--bg-200)' }}>
                      <tr>
                        {['Product', 'Description', 'Ordered', 'Received', 'Unit Cost', 'VAT%', 'Total', ''].map(h => (
                          <th key={h} className="px-2 py-2 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.65rem', letterSpacing: '0.05em', textTransform: 'uppercase' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {lines.map((l, i) => (
                        <tr key={i} style={{ borderTop: '1px solid var(--border)' }}>
                          <td className="px-2 py-1.5">
                            <select className="input text-xs py-1 px-2" value={l.product_id} onChange={e => updateLine(i, 'product_id', e.target.value)}>
                              <option value="">Select</option>
                              {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                            </select>
                          </td>
                          <td className="px-2 py-1.5"><input className="input text-xs py-1 px-2" value={l.description} onChange={e => updateLine(i, 'description', e.target.value)} /></td>
                          <td className="px-2 py-1.5"><input className="input text-xs py-1 px-2 w-16" type="number" value={l.quantity_ordered} onChange={e => updateLine(i, 'quantity_ordered', e.target.value)} /></td>
                          <td className="px-2 py-1.5"><input className="input text-xs py-1 px-2 w-16" type="number" value={l.quantity_received} onChange={e => updateLine(i, 'quantity_received', e.target.value)} /></td>
                          <td className="px-2 py-1.5"><input className="input text-xs py-1 px-2 w-20 text-amount" type="number" value={l.unit_cost} onChange={e => updateLine(i, 'unit_cost', e.target.value)} /></td>
                          <td className="px-2 py-1.5"><input className="input text-xs py-1 px-2 w-14" type="number" value={l.vat_rate} onChange={e => updateLine(i, 'vat_rate', e.target.value)} /></td>
                          <td className="px-2 py-1.5 text-amount font-medium" style={{ color: 'var(--accent)' }}>{fmtZMW(calcLine(l).total)}</td>
                          <td className="px-2 py-1.5">
                            <button onClick={() => removeLine(i)}><Trash2 size={13} style={{ color: 'var(--danger)' }} /></button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* GRN Totals */}
              <div className="flex justify-end gap-6 text-sm border-t pt-3" style={{ borderColor: 'var(--border)' }}>
                <span style={{ color: 'var(--text-muted)' }}>Subtotal: <span className="text-amount">{fmtZMW(totals.subtotal)}</span></span>
                <span style={{ color: 'var(--text-muted)' }}>VAT: <span className="text-amount">{fmtZMW(totals.vat)}</span></span>
                <span style={{ fontFamily: 'Syne', fontWeight: 700 }}>Total: <span className="text-amount" style={{ color: 'var(--accent)' }}>{fmtZMW(totals.total)}</span></span>
              </div>
            </div>
            <div className="px-6 py-4 border-t flex gap-3 justify-end" style={{ borderColor: 'var(--border)' }}>
              <button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button>
              <button className="btn-primary" onClick={saveGRN} disabled={saving}>
                {saving ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />}
                {saving ? 'Saving...' : 'Save GRN'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View GRN Modal */}
      {viewReceipt && (
        <div className="modal-overlay" onClick={() => setViewReceipt(null)}>
          <div className="modal-content max-w-2xl" onClick={e => e.stopPropagation()}>
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
              <div>
                <h2 style={{ fontFamily: 'Syne', fontWeight: 700 }}>GRN Details</h2>
                <div className="font-mono text-xs mt-0.5" style={{ color: 'var(--accent)' }}>{viewReceipt.grn_number}</div>
              </div>
              <div className="flex items-center gap-2">
                {viewReceipt.status === 'draft' && (
                  <button className="btn-primary text-xs px-3 py-1.5" onClick={confirmGRN} disabled={confirming}>
                    {confirming ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle2 size={13} />}
                    Confirm & Update Stock
                  </button>
                )}
                <button onClick={() => setViewReceipt(null)}><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
              </div>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span style={{ color: 'var(--text-muted)' }}>Supplier: </span><strong>{viewReceipt.suppliers?.name ?? '—'}</strong></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Date: </span><strong>{format(new Date(viewReceipt.receipt_date), 'dd MMM yyyy')}</strong></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Supplier Ref: </span><span className="font-mono">{viewReceipt.supplier_invoice_ref ?? '—'}</span></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Status: </span>{statusBadge(viewReceipt.status)}</div>
              </div>
              <div className="rounded-lg overflow-hidden" style={{ border: '1px solid var(--border)' }}>
                <table className="w-full text-sm">
                  <thead style={{ background: 'var(--bg-200)' }}>
                    <tr>
                      {['Item', 'Qty Received', 'Unit Cost', 'VAT', 'Total'].map(h => (
                        <th key={h} className="px-3 py-2 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.7rem', letterSpacing: '0.05em', textTransform: 'uppercase' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {viewItems.map(item => (
                      <tr key={item.id} style={{ borderTop: '1px solid var(--border)' }}>
                        <td className="px-3 py-2.5" style={{ fontFamily: 'Syne', fontWeight: 500 }}>{item.description}</td>
                        <td className="px-3 py-2.5 text-amount">{item.quantity_received}</td>
                        <td className="px-3 py-2.5 text-amount">{fmtZMW(item.unit_cost)}</td>
                        <td className="px-3 py-2.5 text-amount" style={{ color: 'var(--text-dim)' }}>{fmtZMW(item.vat_amount)}</td>
                        <td className="px-3 py-2.5 text-amount font-medium" style={{ color: 'var(--accent)' }}>{fmtZMW(item.line_total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex justify-end gap-5 text-sm">
                <span style={{ color: 'var(--text-muted)' }}>Subtotal: <span className="text-amount">{fmtZMW(viewReceipt.subtotal)}</span></span>
                <span style={{ color: 'var(--text-muted)' }}>VAT: <span className="text-amount">{fmtZMW(viewReceipt.vat_amount)}</span></span>
                <span style={{ fontFamily: 'Syne', fontWeight: 700 }}>Total: <span className="text-amount" style={{ color: 'var(--accent)' }}>{fmtZMW(viewReceipt.total_amount)}</span></span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  function statusBadge(s: string) {
    const m: Record<string, string> = { draft: 'badge-yellow', confirmed: 'badge-green', cancelled: 'badge-gray' }
    return <span className={`badge ${m[s] ?? 'badge-gray'}`}>{s}</span>
  }
}
