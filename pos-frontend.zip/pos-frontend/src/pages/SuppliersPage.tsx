import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Supplier } from '@/types'
import { Plus, Search, Edit2, X, Loader2, CheckCircle2, ClipboardList } from 'lucide-react'

const empty = { name: '', contact_person: '', email: '', phone: '', address: '', tpin: '', payment_terms: '', is_active: true, notes: '' }

export default function SuppliersPage() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Supplier | null>(null)
  const [form, setForm] = useState<any>(empty)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState(false)

  useEffect(() => { load() }, [])

  const load = async () => {
    const { data } = await supabase.from('suppliers').select('*').order('name')
    setSuppliers(data ?? [])
    setLoading(false)
  }

  const openAdd = () => { setEditing(null); setForm(empty); setShowModal(true) }
  const openEdit = (s: Supplier) => { setEditing(s); setForm({ ...s }); setShowModal(true) }

  const save = async () => {
    setSaving(true)
    if (editing) await supabase.from('suppliers').update(form).eq('id', editing.id)
    else await supabase.from('suppliers').insert(form)
    setSaving(false); setSuccess(true)
    setTimeout(() => setSuccess(false), 2000)
    setShowModal(false); load()
  }

  const filtered = suppliers.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.phone?.includes(search) || s.email?.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return <div className="flex items-center justify-center h-full"><div className="w-8 h-8 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>

  return (
    <div className="p-6 space-y-5 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Suppliers</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{suppliers.length} suppliers registered</p>
        </div>
        <button className="btn-primary" onClick={openAdd}><Plus size={16} />Add Supplier</button>
      </div>

      <div className="relative max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
        <input className="input pl-9" placeholder="Search suppliers..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Supplier', 'Phone', 'Email', 'TPIN', 'Payment Terms', 'Status', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.72rem', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(s => (
                <tr key={s.id} className="table-row">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold"
                        style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)', color: 'var(--info)', fontFamily: 'Syne' }}>
                        {s.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium" style={{ fontFamily: 'Syne' }}>{s.name}</div>
                        {s.contact_person && <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{s.contact_person}</div>}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">{s.phone ?? '—'}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'var(--text-dim)' }}>{s.email ?? '—'}</td>
                  <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--text-dim)' }}>{s.tpin ?? '—'}</td>
                  <td className="px-4 py-3 text-xs">{s.payment_terms ?? '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`badge ${s.is_active ? 'badge-green' : 'badge-gray'}`}>{s.is_active ? 'Active' : 'Inactive'}</span>
                  </td>
                  <td className="px-4 py-3">
                    <button className="btn-secondary px-3 py-1.5 text-xs" onClick={() => openEdit(s)}><Edit2 size={12} />Edit</button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-12 text-center" style={{ color: 'var(--text-muted)' }}>
                  <ClipboardList size={32} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
                  No suppliers found
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
              <h2 style={{ fontFamily: 'Syne', fontWeight: 700 }}>{editing ? 'Edit Supplier' : 'New Supplier'}</h2>
              <button onClick={() => setShowModal(false)}><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
            </div>
            <div className="px-6 py-5 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><label className="label">Company Name *</label><input className="input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
                <div><label className="label">Contact Person</label><input className="input" value={form.contact_person} onChange={e => setForm({ ...form, contact_person: e.target.value })} /></div>
                <div><label className="label">Phone</label><input className="input" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
                <div><label className="label">Email</label><input className="input" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
                <div><label className="label">TPIN (ZRA)</label><input className="input" value={form.tpin} onChange={e => setForm({ ...form, tpin: e.target.value })} /></div>
                <div className="col-span-2"><label className="label">Address</label><textarea className="input resize-none" rows={2} value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
                <div><label className="label">Payment Terms</label><input className="input" value={form.payment_terms} placeholder="e.g. 30 days net" onChange={e => setForm({ ...form, payment_terms: e.target.value })} /></div>
                <div className="flex items-center gap-3 pt-5">
                  <input type="checkbox" id="sActive" checked={form.is_active} onChange={e => setForm({ ...form, is_active: e.target.checked })} className="w-4 h-4" />
                  <label htmlFor="sActive" className="text-sm">Active supplier</label>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t flex gap-3 justify-end" style={{ borderColor: 'var(--border)' }}>
              <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn-primary" onClick={save} disabled={saving || !form.name}>
                {saving ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />}
                {saving ? 'Saving...' : 'Save Supplier'}
              </button>
            </div>
          </div>
        </div>
      )}

      {success && (
        <div className="fixed bottom-6 right-6 flex items-center gap-3 px-5 py-4 rounded-xl"
          style={{ background: 'var(--bg-200)', border: '1px solid var(--border-accent)', boxShadow: '0 0 30px var(--accent-glow)', animation: 'slideUp 0.3s ease-out' }}>
          <CheckCircle2 size={18} style={{ color: 'var(--accent)' }} /><span style={{ fontFamily: 'Syne', fontWeight: 600 }}>Supplier saved</span>
        </div>
      )}
    </div>
  )
}
