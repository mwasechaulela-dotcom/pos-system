import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Invoice, InvoiceItem } from '@/types'
import { Search, Eye, Printer, FileText, CheckCircle2, X } from 'lucide-react'
import { format } from 'date-fns'

const fmtZMW = (n: number) => `ZMW ${Number(n).toLocaleString('en-ZM', { minimumFractionDigits: 2 })}`

const statusBadge = (status: string) => {
  const map: Record<string, string> = { draft: 'badge-gray', issued: 'badge-blue', paid: 'badge-green', partial: 'badge-yellow', overdue: 'badge-red', cancelled: 'badge-gray', void: 'badge-gray' }
  return <span className={`badge ${map[status] ?? 'badge-gray'}`}>{status}</span>
}

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [viewInv, setViewInv] = useState<any | null>(null)
  const [viewItems, setViewItems] = useState<InvoiceItem[]>([])

  useEffect(() => { load() }, [])

  const load = async () => {
    const { data } = await supabase.from('v_invoice_summary').select('*').order('invoice_date', { ascending: false })
    setInvoices(data ?? [])
    setLoading(false)
  }

  const openView = async (inv: any) => {
    setViewInv(inv)
    const { data } = await supabase.from('invoice_items').select('*, products(name, sku)').eq('invoice_id', inv.id)
    setViewItems(data ?? [])
  }

  const markPaid = async (id: string) => {
    await supabase.from('invoices').update({ status: 'paid', amount_paid: viewInv.total_amount }).eq('id', id)
    load()
    setViewInv((prev: any) => ({ ...prev, status: 'paid' }))
  }

  const printInvoice = () => window.print()

  const filtered = invoices.filter(i => {
    const matchSearch = i.invoice_number?.toLowerCase().includes(search.toLowerCase()) ||
      i.customer_name?.toLowerCase().includes(search.toLowerCase())
    const matchStatus = !statusFilter || i.status === statusFilter
    return matchSearch && matchStatus
  })

  if (loading) return <div className="flex items-center justify-center h-full"><div className="w-8 h-8 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>

  return (
    <div className="p-6 space-y-5 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Invoices</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{invoices.length} total invoices</p>
        </div>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
          <input className="input pl-9" placeholder="Search invoice # or customer..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="input w-auto" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          <option value="">All statuses</option>
          {['draft','issued','paid','partial','overdue','cancelled','void'].map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Invoice #', 'Customer', 'Date', 'Due Date', 'Amount', 'Paid', 'Balance', 'Status', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.72rem', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(inv => (
                <tr key={inv.id} className="table-row">
                  <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--accent)' }}>{inv.invoice_number}</td>
                  <td className="px-4 py-3" style={{ fontFamily: 'Syne' }}>{inv.customer_name ?? <span style={{ color: 'var(--text-muted)' }}>Walk-in</span>}</td>
                  <td className="px-4 py-3" style={{ color: 'var(--text-dim)' }}>{format(new Date(inv.invoice_date), 'dd MMM yyyy')}</td>
                  <td className="px-4 py-3" style={{ color: inv.due_date && new Date(inv.due_date) < new Date() && inv.status !== 'paid' ? 'var(--danger)' : 'var(--text-dim)' }}>
                    {inv.due_date ? format(new Date(inv.due_date), 'dd MMM yyyy') : '—'}
                  </td>
                  <td className="px-4 py-3 text-amount font-medium">{fmtZMW(inv.total_amount)}</td>
                  <td className="px-4 py-3 text-amount" style={{ color: 'var(--accent)' }}>{fmtZMW(inv.amount_paid)}</td>
                  <td className="px-4 py-3 text-amount" style={{ color: inv.balance_due > 0 ? 'var(--danger)' : 'var(--text-muted)' }}>{fmtZMW(inv.balance_due)}</td>
                  <td className="px-4 py-3">{statusBadge(inv.status)}</td>
                  <td className="px-4 py-3">
                    <button className="btn-secondary px-3 py-1.5 text-xs" onClick={() => openView(inv)}><Eye size={12} />View</button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-12 text-center" style={{ color: 'var(--text-muted)' }}>
                  <FileText size={32} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
                  No invoices found
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice detail modal */}
      {viewInv && (
        <div className="modal-overlay" onClick={() => setViewInv(null)}>
          <div className="modal-content max-w-2xl" onClick={e => e.stopPropagation()} id="printable-invoice">
            {/* Invoice header */}
            <div className="px-6 py-5 border-b flex items-start justify-between" style={{ borderColor: 'var(--border)' }}>
              <div>
                <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.1rem', color: 'var(--accent)', letterSpacing: '-0.02em' }}>SWIFT POS</div>
                <div className="font-mono text-xs mt-1" style={{ color: 'var(--text-muted)' }}>{viewInv.invoice_number}</div>
              </div>
              <div className="flex items-center gap-2">
                {viewInv.status !== 'paid' && viewInv.status !== 'void' && viewInv.status !== 'cancelled' && (
                  <button className="btn-primary text-xs px-3 py-1.5" onClick={() => markPaid(viewInv.id)}>
                    <CheckCircle2 size={13} />Mark Paid
                  </button>
                )}
                <button className="btn-secondary text-xs px-3 py-1.5" onClick={printInvoice}>
                  <Printer size={13} />Print
                </button>
                <button onClick={() => setViewInv(null)}><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
              </div>
            </div>

            <div className="px-6 py-5 space-y-5">
              {/* Customer + dates */}
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <div className="section-title mb-2">Bill To</div>
                  <div style={{ fontFamily: 'Syne', fontWeight: 600 }}>{viewInv.customer_name ?? 'Walk-in Customer'}</div>
                  {viewInv.customer_phone && <div className="text-sm" style={{ color: 'var(--text-muted)' }}>{viewInv.customer_phone}</div>}
                </div>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span style={{ color: 'var(--text-muted)' }}>Invoice Date</span>
                    <span>{format(new Date(viewInv.invoice_date), 'dd MMM yyyy')}</span>
                  </div>
                  {viewInv.due_date && (
                    <div className="flex justify-between">
                      <span style={{ color: 'var(--text-muted)' }}>Due Date</span>
                      <span>{format(new Date(viewInv.due_date), 'dd MMM yyyy')}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span style={{ color: 'var(--text-muted)' }}>Status</span>
                    {statusBadge(viewInv.status)}
                  </div>
                  <div className="flex justify-between">
                    <span style={{ color: 'var(--text-muted)' }}>Cashier</span>
                    <span>{viewInv.created_by_name}</span>
                  </div>
                </div>
              </div>

              {/* Line items */}
              <div className="rounded-lg overflow-hidden" style={{ border: '1px solid var(--border)' }}>
                <table className="w-full text-sm">
                  <thead style={{ background: 'var(--bg-200)' }}>
                    <tr>
                      {['Item', 'Qty', 'Unit Price', 'VAT', 'Total'].map(h => (
                        <th key={h} className="px-3 py-2 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.7rem', letterSpacing: '0.05em', textTransform: 'uppercase' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {viewItems.map(item => (
                      <tr key={item.id} style={{ borderTop: '1px solid var(--border)' }}>
                        <td className="px-3 py-2.5">
                          <div style={{ fontFamily: 'Syne', fontWeight: 500 }}>{item.description}</div>
                          {(item.products as any)?.sku && <div className="text-xs font-mono" style={{ color: 'var(--text-muted)' }}>{(item.products as any).sku}</div>}
                        </td>
                        <td className="px-3 py-2.5 text-amount">{item.quantity}</td>
                        <td className="px-3 py-2.5 text-amount">{fmtZMW(item.unit_price)}</td>
                        <td className="px-3 py-2.5 text-amount" style={{ color: 'var(--text-dim)' }}>{fmtZMW(item.vat_amount)}</td>
                        <td className="px-3 py-2.5 text-amount font-medium" style={{ color: 'var(--accent)' }}>{fmtZMW(item.line_total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Totals */}
              <div className="flex justify-end">
                <div className="w-64 space-y-2 text-sm">
                  <div className="flex justify-between" style={{ color: 'var(--text-muted)' }}>
                    <span>Subtotal</span><span className="text-amount">{fmtZMW(viewInv.subtotal)}</span>
                  </div>
                  <div className="flex justify-between" style={{ color: 'var(--text-muted)' }}>
                    <span>VAT</span><span className="text-amount">{fmtZMW(viewInv.vat_amount)}</span>
                  </div>
                  {viewInv.discount_amount > 0 && (
                    <div className="flex justify-between" style={{ color: 'var(--warning)' }}>
                      <span>Discount</span><span className="text-amount">-{fmtZMW(viewInv.discount_amount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold pt-2 border-t" style={{ borderColor: 'var(--border)', fontFamily: 'Syne', fontSize: '1rem' }}>
                    <span>Total</span><span className="text-amount" style={{ color: 'var(--accent)' }}>{fmtZMW(viewInv.total_amount)}</span>
                  </div>
                  <div className="flex justify-between text-xs" style={{ color: 'var(--text-muted)' }}>
                    <span>Amount Paid</span><span className="text-amount">{fmtZMW(viewInv.amount_paid)}</span>
                  </div>
                  {viewInv.balance_due > 0 && (
                    <div className="flex justify-between text-sm font-medium" style={{ color: 'var(--danger)' }}>
                      <span>Balance Due</span><span className="text-amount">{fmtZMW(viewInv.balance_due)}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
