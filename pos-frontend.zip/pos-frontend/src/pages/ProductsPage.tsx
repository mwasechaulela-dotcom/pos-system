import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Product, Category, Supplier } from '@/types'
import { Plus, Search, Edit2, Package, AlertTriangle, X, Loader2, CheckCircle2 } from 'lucide-react'

const fmtZMW = (n: number) => `ZMW ${n.toLocaleString('en-ZM', { minimumFractionDigits: 2 })}`

const emptyProduct = {
  name: '', sku: '', barcode: '', description: '', unit_of_measure: 'each',
  cost_price: 0, selling_price: 0, vat_rate: 16, is_vat_inclusive: false,
  reorder_level: 5, stock_quantity: 0, is_active: true,
  category_id: '', supplier_id: '', image_url: '',
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [catFilter, setCatFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)
  const [form, setForm] = useState<any>(emptyProduct)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState(false)

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    const [prods, cats, sups] = await Promise.all([
      supabase.from('products').select('*, categories(name), suppliers(name)').order('name'),
      supabase.from('categories').select('*').eq('is_active', true).order('name'),
      supabase.from('suppliers').select('*').eq('is_active', true).order('name'),
    ])
    setProducts(prods.data ?? [])
    setCategories(cats.data ?? [])
    setSuppliers(sups.data ?? [])
    setLoading(false)
  }

  const openAdd = () => { setEditing(null); setForm(emptyProduct); setShowModal(true) }
  const openEdit = (p: Product) => { setEditing(p); setForm({ ...p, category_id: p.category_id ?? '', supplier_id: p.supplier_id ?? '' }); setShowModal(true) }

  const save = async () => {
    setSaving(true)
    const payload = {
      name: form.name, sku: form.sku || null, barcode: form.barcode || null,
      description: form.description || null, unit_of_measure: form.unit_of_measure,
      cost_price: parseFloat(form.cost_price), selling_price: parseFloat(form.selling_price),
      vat_rate: parseFloat(form.vat_rate), is_vat_inclusive: form.is_vat_inclusive,
      reorder_level: parseInt(form.reorder_level), is_active: form.is_active,
      category_id: form.category_id || null, supplier_id: form.supplier_id || null,
    }
    if (editing) {
      await supabase.from('products').update(payload).eq('id', editing.id)
    } else {
      await supabase.from('products').insert({ ...payload, stock_quantity: parseFloat(form.stock_quantity) })
    }
    setSaving(false)
    setSuccess(true)
    setTimeout(() => setSuccess(false), 2000)
    setShowModal(false)
    await loadData()
  }

  const filtered = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.sku?.toLowerCase().includes(search.toLowerCase())
    const matchCat = !catFilter || p.category_id === catFilter
    return matchSearch && matchCat
  })

  if (loading) return <div className="flex items-center justify-center h-full"><div className="w-8 h-8 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>

  return (
    <div className="p-6 space-y-5 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Products</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{products.length} items in catalogue</p>
        </div>
        <button className="btn-primary" onClick={openAdd}><Plus size={16} />Add Product</button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
          <input className="input pl-9" placeholder="Search products..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="input w-auto" value={catFilter} onChange={e => setCatFilter(e.target.value)}>
          <option value="">All categories</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Product', 'SKU', 'Category', 'Cost', 'Price', 'Stock', 'Status', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.72rem', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.id} className="table-row">
                  <td className="px-4 py-3">
                    <div className="font-medium" style={{ fontFamily: 'Syne' }}>{p.name}</div>
                    {p.description && <div className="text-xs truncate max-w-xs" style={{ color: 'var(--text-muted)' }}>{p.description}</div>}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--text-dim)' }}>{p.sku ?? '—'}</td>
                  <td className="px-4 py-3"><span className="badge badge-gray">{(p as any).categories?.name ?? '—'}</span></td>
                  <td className="px-4 py-3 text-amount" style={{ color: 'var(--text-dim)' }}>{fmtZMW(p.cost_price)}</td>
                  <td className="px-4 py-3 text-amount font-medium" style={{ color: 'var(--accent)' }}>{fmtZMW(p.selling_price)}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      {p.stock_quantity <= p.reorder_level && <AlertTriangle size={13} style={{ color: 'var(--warning)' }} />}
                      <span className="text-amount" style={{ color: p.stock_quantity <= p.reorder_level ? 'var(--warning)' : 'var(--text)' }}>
                        {p.stock_quantity} {p.unit_of_measure}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`badge ${p.is_active ? 'badge-green' : 'badge-gray'}`}>{p.is_active ? 'Active' : 'Inactive'}</span>
                  </td>
                  <td className="px-4 py-3">
                    <button className="btn-secondary px-3 py-1.5 text-xs" onClick={() => openEdit(p)}><Edit2 size={12} />Edit</button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-12 text-center" style={{ color: 'var(--text-muted)' }}>No products found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
              <h2 style={{ fontFamily: 'Syne', fontWeight: 700 }}>{editing ? 'Edit Product' : 'New Product'}</h2>
              <button onClick={() => setShowModal(false)}><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="label">Product Name *</label>
                  <input className="input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Coca-Cola 500ml" />
                </div>
                <div>
                  <label className="label">SKU</label>
                  <input className="input" value={form.sku} onChange={e => setForm({ ...form, sku: e.target.value })} placeholder="PROD-001" />
                </div>
                <div>
                  <label className="label">Barcode</label>
                  <input className="input" value={form.barcode} onChange={e => setForm({ ...form, barcode: e.target.value })} />
                </div>
                <div>
                  <label className="label">Category</label>
                  <select className="input" value={form.category_id} onChange={e => setForm({ ...form, category_id: e.target.value })}>
                    <option value="">None</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Supplier</label>
                  <select className="input" value={form.supplier_id} onChange={e => setForm({ ...form, supplier_id: e.target.value })}>
                    <option value="">None</option>
                    {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Cost Price (ZMW)</label>
                  <input className="input text-amount" type="number" step="0.01" value={form.cost_price} onChange={e => setForm({ ...form, cost_price: e.target.value })} />
                </div>
                <div>
                  <label className="label">Selling Price (ZMW)</label>
                  <input className="input text-amount" type="number" step="0.01" value={form.selling_price} onChange={e => setForm({ ...form, selling_price: e.target.value })} />
                </div>
                <div>
                  <label className="label">VAT Rate (%)</label>
                  <input className="input" type="number" step="0.01" value={form.vat_rate} onChange={e => setForm({ ...form, vat_rate: e.target.value })} />
                </div>
                <div>
                  <label className="label">Unit of Measure</label>
                  <input className="input" value={form.unit_of_measure} onChange={e => setForm({ ...form, unit_of_measure: e.target.value })} placeholder="each, kg, litre..." />
                </div>
                <div>
                  <label className="label">Reorder Level</label>
                  <input className="input" type="number" value={form.reorder_level} onChange={e => setForm({ ...form, reorder_level: e.target.value })} />
                </div>
                {!editing && (
                  <div>
                    <label className="label">Opening Stock</label>
                    <input className="input text-amount" type="number" value={form.stock_quantity} onChange={e => setForm({ ...form, stock_quantity: e.target.value })} />
                  </div>
                )}
                <div className="col-span-2 flex items-center gap-3">
                  <input type="checkbox" id="active" checked={form.is_active} onChange={e => setForm({ ...form, is_active: e.target.checked })} className="w-4 h-4" />
                  <label htmlFor="active" className="text-sm">Active (visible in POS)</label>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t flex gap-3 justify-end" style={{ borderColor: 'var(--border)' }}>
              <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn-primary" onClick={save} disabled={saving || !form.name}>
                {saving ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />}
                {saving ? 'Saving...' : 'Save Product'}
              </button>
            </div>
          </div>
        </div>
      )}

      {success && (
        <div className="fixed bottom-6 right-6 flex items-center gap-3 px-5 py-4 rounded-xl"
          style={{ background: 'var(--bg-200)', border: '1px solid var(--border-accent)', boxShadow: '0 0 30px var(--accent-glow)', animation: 'slideUp 0.3s ease-out' }}>
          <CheckCircle2 size={18} style={{ color: 'var(--accent)' }} />
          <span style={{ fontFamily: 'Syne', fontWeight: 600 }}>Product saved</span>
        </div>
      )}
    </div>
  )
}
