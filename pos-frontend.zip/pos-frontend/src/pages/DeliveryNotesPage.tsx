import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { DeliveryNote, Customer, Product } from '@/types'
import { Plus, Search, Eye, X, Loader2, CheckCircle2, Truck, Printer } from 'lucide-react'
import { format } from 'date-fns'
import { useAuth } from '@/hooks/useAuth'

const fmtDate = (d: string) => format(new Date(d), 'dd MMM yyyy')

export default function DeliveryNotesPage() {
  const { profile } = useAuth()
  const [notes, setNotes] = useState<any[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [invoices, setInvoices] = useState<any[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [viewNote, setViewNote] = useState<any | null>(null)
  const [viewItems, setViewItems] = useState<any[]>([])
  const [saving, setSaving] = useState(false)

  const [form, setForm] = useState({ customer_id: '', invoice_id: '', delivery_date: format(new Date(), 'yyyy-MM-dd'), delivery_address: '', recipient_name: '', notes: '' })
  const [lines, setLines] = useState<any[]>([{ product_id: '', description: '', quantity: '', unit_of_measure: 'each' }])

  useEffect(() => { load() }, [])

  const load = async () => {
    const [dns, custs, invs, prods] = await Promise.all([
      supabase.from('delivery_notes').select('*, customers(name), invoices(invoice_number), profiles(full_name)').order('created_at', { ascending: false }),
      supabase.from('customers').select('*').eq('is_active', true).order('name'),
      supabase.from('invoices').select('id, invoice_number, customer_id').in('status', ['issued', 'paid', 'partial']).order('invoice_number', { ascending: false }),
      supabase.from('products').select('*').eq('is_active', true).order('name'),
    ])
    setNotes(dns.data ?? [])
    setCustomers(custs.data ?? [])
    setInvoices(invs.data ?? [])
    setProducts(prods.data ?? [])
    setLoading(false)
  }

  const addLine = () => setLines(prev => [...prev, { product_id: '', description: '', quantity: '', unit_of_measure: 'each' }])
  const removeLine = (i: number) => setLines(prev => prev.filter((_, idx) => idx !== i))
  const updateLine = (i: number, field: string, value: string) => {
    setLines(prev => prev.map((l, idx) => {
      if (idx !== i) return l
      const updated = { ...l, [field]: value }
      if (field === 'product_id' && value) {
        const prod = products.find(p => p.id === value)
        if (prod) { updated.description = prod.name; updated.unit_of_measure = prod.unit_of_measure }
      }
      return updated
    }))
  }

  const save = async () => {
    setSaving(true)
    try {
      const docNum = (await supabase.rpc('generate_document_number', { p_type: 'delivery_note' })).data
      const { data: dn, error } = await supabase.from('delivery_notes').insert({
        dn_number: docNum,
        customer_id: form.customer_id || null,
        invoice_id: form.invoice_id || null,
        issued_by: profile?.id,
        delivery_date: form.delivery_date,
        status: 'issued',
        delivery_address: form.delivery_address || null,
        recipient_name: form.recipient_name || null,
        notes: form.notes || null,
      }).select().single()
      if (error) throw error

      const items = lines.filter(l => l.description && l.quantity).map(l => ({
        delivery_note_id: dn.id,
        product_id: l.product_id || null,
        description: l.description,
        quantity: parseFloat(l.quantity),
        unit_of_measure: l.unit_of_measure,
      }))
      await supabase.from('delivery_note_items').insert(items)
      setShowNew(false)
      setForm({ customer_id: '', invoice_id: '', delivery_date: format(new Date(), 'yyyy-MM-dd'), delivery_address: '', recipient_name: '', notes: '' })
      setLines([{ product_id: '', description: '', quantity: '', unit_of_measure: 'each' }])
      load()
    } catch (err: any) { alert('Error: ' + err.message) }
    setSaving(false)
  }

  const openView = async (n: any) => {
    setViewNote(n)
    const { data } = await supabase.from('delivery_note_items').select('*, products(name)').eq('delivery_note_id', n.id)
    setViewItems(data ?? [])
  }

  const updateStatus = async (id: string, status: string) => {
    await supabase.from('delivery_notes').update({ status }).eq('id', id)
    setViewNote((prev: any) => ({ ...prev, status }))
    load()
  }

  const statusBadge = (s: string) => {
    const m: Record<string, string> = { draft: 'badge-gray', issued: 'badge-blue', delivered: 'badge-green', cancelled: 'badge-gray' }
    return <span className={`badge ${m[s] ?? 'badge-gray'}`}>{s}</span>
  }

  const filtered = notes.filter(n =>
    n.dn_number?.toLowerCase().includes(search.toLowerCase()) ||
    n.customers?.name?.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return <div className="flex items-center justify-center h-full"><div className="w-8 h-8 rounded-full border-2 border-transparent border-t-green-400 animate-spin" /></div>

  return (
    <div className="p-6 space-y-5 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Delivery Notes</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{notes.length} delivery notes issued</p>
        </div>
        <button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={16} />New Delivery Note</button>
      </div>

      <div className="relative max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
        <input className="input pl-9" placeholder="Search DN # or customer..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['DN #', 'Customer', 'Invoice', 'Date', 'Recipient', 'Status', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.72rem', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(n => (
                <tr key={n.id} className="table-row">
                  <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--accent)' }}>{n.dn_number}</td>
                  <td className="px-4 py-3" style={{ fontFamily: 'Syne' }}>{n.customers?.name ?? '—'}</td>
                  <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--text-dim)' }}>{n.invoices?.invoice_number ?? '—'}</td>
                  <td className="px-4 py-3" style={{ color: 'var(--text-dim)' }}>{fmtDate(n.delivery_date)}</td>
                  <td className="px-4 py-3 text-xs">{n.recipient_name ?? '—'}</td>
                  <td className="px-4 py-3">{statusBadge(n.status)}</td>
                  <td className="px-4 py-3">
                    <button className="btn-secondary px-3 py-1.5 text-xs" onClick={() => openView(n)}><Eye size={12} />View</button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-12 text-center" style={{ color: 'var(--text-muted)' }}>
                  <Truck size={32} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />No delivery notes found
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New DN Modal */}
      {showNew && (
        <div className="modal-overlay" onClick={() => setShowNew(false)}>
          <div className="modal-content max-w-2xl" onClick={e => e.stopPropagation()}>
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
              <h2 style={{ fontFamily: 'Syne', fontWeight: 700 }}>New Delivery Note</h2>
              <button onClick={() => setShowNew(false)}><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Customer</label>
                  <select className="input" value={form.customer_id} onChange={e => setForm({ ...form, customer_id: e.target.value })}>
                    <option value="">Select customer</option>
                    {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Linked Invoice</label>
                  <select className="input" value={form.invoice_id} onChange={e => setForm({ ...form, invoice_id: e.target.value })}>
                    <option value="">None</option>
                    {invoices.filter(i => !form.customer_id || i.customer_id === form.customer_id).map(i => (
                      <option key={i.id} value={i.id}>{i.invoice_number}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Delivery Date</label>
                  <input type="date" className="input" value={form.delivery_date} onChange={e => setForm({ ...form, delivery_date: e.target.value })} />
                </div>
                <div>
                  <label className="label">Recipient Name</label>
                  <input className="input" value={form.recipient_name} placeholder="Person receiving goods" onChange={e => setForm({ ...form, recipient_name: e.target.value })} />
                </div>
                <div className="col-span-2">
                  <label className="label">Delivery Address</label>
                  <textarea className="input resize-none" rows={2} value={form.delivery_address} onChange={e => setForm({ ...form, delivery_address: e.target.value })} />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.875rem' }}>Items</div>
                  <button className="btn-secondary text-xs px-3 py-1.5" onClick={addLine}><Plus size={12} />Add Item</button>
                </div>
                <div className="space-y-2">
                  {lines.map((l, i) => (
                    <div key={i} className="grid grid-cols-12 gap-2 items-center">
                      <div className="col-span-4">
                        <select className="input text-sm py-1.5" value={l.product_id} onChange={e => updateLine(i, 'product_id', e.target.value)}>
                          <option value="">Select product</option>
                          {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                      </div>
                      <div className="col-span-4">
                        <input className="input text-sm py-1.5" value={l.description} placeholder="Description" onChange={e => updateLine(i, 'description', e.target.value)} />
                      </div>
                      <div className="col-span-2">
                        <input className="input text-sm py-1.5 text-amount" type="number" placeholder="Qty" value={l.quantity} onChange={e => updateLine(i, 'quantity', e.target.value)} />
                      </div>
                      <div className="col-span-1">
                        <input className="input text-sm py-1.5" value={l.unit_of_measure} onChange={e => updateLine(i, 'unit_of_measure', e.target.value)} />
                      </div>
                      <div className="col-span-1 flex justify-center">
                        <button onClick={() => removeLine(i)}><X size={13} style={{ color: 'var(--danger)' }} /></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t flex gap-3 justify-end" style={{ borderColor: 'var(--border)' }}>
              <button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button>
              <button className="btn-primary" onClick={save} disabled={saving}>
                {saving ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />}
                {saving ? 'Saving...' : 'Issue Delivery Note'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View DN Modal */}
      {viewNote && (
        <div className="modal-overlay" onClick={() => setViewNote(null)}>
          <div className="modal-content max-w-2xl" onClick={e => e.stopPropagation()}>
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
              <div>
                <h2 style={{ fontFamily: 'Syne', fontWeight: 700 }}>Delivery Note</h2>
                <div className="font-mono text-xs mt-0.5" style={{ color: 'var(--accent)' }}>{viewNote.dn_number}</div>
              </div>
              <div className="flex items-center gap-2">
                {viewNote.status === 'issued' && (
                  <button className="btn-primary text-xs px-3 py-1.5" onClick={() => updateStatus(viewNote.id, 'delivered')}>
                    <CheckCircle2 size={13} />Mark Delivered
                  </button>
                )}
                <button className="btn-secondary text-xs px-3 py-1.5" onClick={() => window.print()}><Printer size={13} />Print</button>
                <button onClick={() => setViewNote(null)}><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
              </div>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span style={{ color: 'var(--text-muted)' }}>Customer: </span><strong>{viewNote.customers?.name ?? '—'}</strong></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Invoice: </span><span className="font-mono">{viewNote.invoices?.invoice_number ?? '—'}</span></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Date: </span><strong>{fmtDate(viewNote.delivery_date)}</strong></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Status: </span>{statusBadge(viewNote.status)}</div>
                {viewNote.recipient_name && <div className="col-span-2"><span style={{ color: 'var(--text-muted)' }}>Recipient: </span><strong>{viewNote.recipient_name}</strong></div>}
                {viewNote.delivery_address && <div className="col-span-2"><span style={{ color: 'var(--text-muted)' }}>Address: </span>{viewNote.delivery_address}</div>}
              </div>

              <div className="rounded-lg overflow-hidden" style={{ border: '1px solid var(--border)' }}>
                <table className="w-full text-sm">
                  <thead style={{ background: 'var(--bg-200)' }}>
                    <tr>
                      {['Description', 'Quantity', 'Unit'].map(h => (
                        <th key={h} className="px-3 py-2 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.7rem', letterSpacing: '0.05em', textTransform: 'uppercase' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {viewItems.map(item => (
                      <tr key={item.id} style={{ borderTop: '1px solid var(--border)' }}>
                        <td className="px-3 py-2.5" style={{ fontFamily: 'Syne', fontWeight: 500 }}>{item.description}</td>
                        <td className="px-3 py-2.5 text-amount">{item.quantity}</td>
                        <td className="px-3 py-2.5 text-xs" style={{ color: 'var(--text-dim)' }}>{item.unit_of_measure}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Signature box */}
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="rounded-lg p-4" style={{ border: '1px dashed var(--border)' }}>
                  <div className="text-xs mb-8" style={{ color: 'var(--text-muted)', fontFamily: 'Syne' }}>ISSUED BY</div>
                  <div className="text-xs border-t pt-2" style={{ borderColor: 'var(--border)', color: 'var(--text-muted)' }}>Signature / Date</div>
                </div>
                <div className="rounded-lg p-4" style={{ border: '1px dashed var(--border)' }}>
                  <div className="text-xs mb-8" style={{ color: 'var(--text-muted)', fontFamily: 'Syne' }}>RECEIVED BY</div>
                  <div className="text-xs border-t pt-2" style={{ borderColor: 'var(--border)', color: 'var(--text-muted)' }}>Signature / Date</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  function statusBadge(s: string) {
    const m: Record<string, string> = { draft: 'badge-gray', issued: 'badge-blue', delivered: 'badge-green', cancelled: 'badge-gray' }
    return <span className={`badge ${m[s] ?? 'badge-gray'}`}>{s}</span>
  }
}
