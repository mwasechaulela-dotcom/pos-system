import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Search, ArrowUpCircle, ArrowDownCircle, ArrowLeftRight, RefreshCw } from 'lucide-react'
import { format } from 'date-fns'

const fmtZMW = (n: number) => `ZMW ${Number(n).toLocaleString('en-ZM', { minimumFractionDigits: 2 })}`

const typeColors: Record<string, { bg: string; color: string; label: string }> = {
  sale:           { bg: 'rgba(239,68,68,0.1)',    color: 'var(--danger)',  label: 'Sale' },
  purchase:       { bg: 'rgba(34,197,94,0.1)',     color: 'var(--accent)', label: 'Purchase' },
  adjustment_in:  { bg: 'rgba(59,130,246,0.1)',    color: 'var(--info)',   label: 'Adj. In' },
  adjustment_out: { bg: 'rgba(245,158,11,0.1)',    color: 'var(--warning)',label: 'Adj. Out' },
  return_in:      { bg: 'rgba(34,197,94,0.1)',     color: 'var(--accent)', label: 'Return In' },
  return_out:     { bg: 'rgba(239,68,68,0.1)',     color: 'var(--danger)', label: 'Return Out' },
  opening_stock:  { bg: 'rgba(148,163,184,0.1)',   color: 'var(--text-dim)', label: 'Opening' },
}

export default function StockMovementsPage() {
  const [movements, setMovements] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [page, setPage] = useState(0)
  const PAGE = 50

  useEffect(() => { load() }, [page, typeFilter])

  const load = async () => {
    setLoading(true)
    let q = supabase.from('v_stock_ledger').select('*').order('created_at', { ascending: false }).range(page * PAGE, (page + 1) * PAGE - 1)
    if (typeFilter) q = q.eq('movement_type', typeFilter)
    const { data } = await q
    setMovements(data ?? [])
    setLoading(false)
  }

  const filtered = movements.filter(m =>
    m.product_name?.toLowerCase().includes(search.toLowerCase()) ||
    m.reference_number?.toLowerCase().includes(search.toLowerCase()) ||
    m.sku?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-6 space-y-5 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Stock Movements</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Immutable audit log of all inventory changes</p>
        </div>
        <button className="btn-secondary" onClick={load}><RefreshCw size={15} />Refresh</button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
          <input className="input pl-9" placeholder="Search product or reference..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="input w-auto" value={typeFilter} onChange={e => { setTypeFilter(e.target.value); setPage(0) }}>
          <option value="">All types</option>
          {Object.entries(typeColors).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 stagger">
        {[
          { label: 'Sales', type: 'sale', icon: ArrowDownCircle, color: 'var(--danger)' },
          { label: 'Purchases', type: 'purchase', icon: ArrowUpCircle, color: 'var(--accent)' },
          { label: 'Adjustments In', type: 'adjustment_in', icon: ArrowUpCircle, color: 'var(--info)' },
          { label: 'Adjustments Out', type: 'adjustment_out', icon: ArrowDownCircle, color: 'var(--warning)' },
        ].map(({ label, type, icon: Icon, color }) => {
          const count = movements.filter(m => m.movement_type === type).length
          return (
            <div key={type} className="stat-card cursor-pointer" onClick={() => setTypeFilter(typeFilter === type ? '' : type)}
              style={{ borderColor: typeFilter === type ? color : undefined }}>
              <div className="flex items-center justify-between">
                <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', fontFamily: 'Syne', letterSpacing: '0.05em', textTransform: 'uppercase' }}>{label}</span>
                <Icon size={15} style={{ color }} />
              </div>
              <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1.5rem', color }}>{count}</div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>movements (this page)</div>
            </div>
          )
        })}
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Date/Time', 'Product', 'SKU', 'Type', 'Reference', 'In', 'Out', 'Before', 'After', 'By'].map(h => (
                  <th key={h} className="px-3 py-3 text-left" style={{ color: 'var(--text-muted)', fontFamily: 'Syne', fontSize: '0.7rem', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={10} className="px-4 py-10 text-center">
                  <div className="w-6 h-6 rounded-full border-2 border-transparent border-t-green-400 animate-spin mx-auto" />
                </td></tr>
              ) : filtered.length ? filtered.map((m, i) => {
                const tc = typeColors[m.movement_type] ?? { bg: 'rgba(148,163,184,0.1)', color: 'var(--text-dim)', label: m.movement_type }
                return (
                  <tr key={i} className="table-row">
                    <td className="px-3 py-2.5 font-mono text-xs" style={{ color: 'var(--text-dim)' }}>
                      {format(new Date(m.created_at), 'dd MMM yyyy HH:mm')}
                    </td>
                    <td className="px-3 py-2.5" style={{ fontFamily: 'Syne', fontWeight: 500 }}>{m.product_name}</td>
                    <td className="px-3 py-2.5 font-mono text-xs" style={{ color: 'var(--text-muted)' }}>{m.sku ?? '—'}</td>
                    <td className="px-3 py-2.5">
                      <span className="badge text-xs px-2 py-0.5" style={{ background: tc.bg, color: tc.color }}>{tc.label}</span>
                    </td>
                    <td className="px-3 py-2.5 font-mono text-xs" style={{ color: 'var(--accent)' }}>{m.reference_number ?? '—'}</td>
                    <td className="px-3 py-2.5 text-amount" style={{ color: m.quantity_in > 0 ? 'var(--accent)' : 'var(--text-muted)' }}>
                      {m.quantity_in > 0 ? `+${m.quantity_in}` : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-amount" style={{ color: m.quantity_out > 0 ? 'var(--danger)' : 'var(--text-muted)' }}>
                      {m.quantity_out > 0 ? `-${m.quantity_out}` : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-amount" style={{ color: 'var(--text-muted)' }}>{m.quantity_before}</td>
                    <td className="px-3 py-2.5 text-amount font-medium">{m.quantity_after}</td>
                    <td className="px-3 py-2.5 text-xs" style={{ color: 'var(--text-dim)' }}>{m.created_by ?? '—'}</td>
                  </tr>
                )
              }) : (
                <tr><td colSpan={10} className="px-4 py-12 text-center" style={{ color: 'var(--text-muted)' }}>
                  <ArrowLeftRight size={32} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
                  No movements found
                </td></tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-4 py-3 flex items-center justify-between border-t" style={{ borderColor: 'var(--border)' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Showing {PAGE} per page</span>
          <div className="flex gap-2">
            <button className="btn-secondary text-xs px-3 py-1.5" disabled={page === 0} onClick={() => setPage(p => p - 1)}>← Previous</button>
            <button className="btn-secondary text-xs px-3 py-1.5" disabled={movements.length < PAGE} onClick={() => setPage(p => p + 1)}>Next →</button>
          </div>
        </div>
      </div>
    </div>
  )
}
