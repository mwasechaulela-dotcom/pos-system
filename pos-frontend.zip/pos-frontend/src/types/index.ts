export type UserRole = 'admin' | 'manager' | 'cashier'

export interface Profile {
  id: string
  full_name: string
  role: UserRole
  phone?: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Category {
  id: string
  name: string
  description?: string
  is_active: boolean
  created_at: string
}

export interface Supplier {
  id: string
  name: string
  contact_person?: string
  email?: string
  phone?: string
  address?: string
  tpin?: string
  payment_terms?: string
  is_active: boolean
  notes?: string
  created_at: string
}

export interface Customer {
  id: string
  name: string
  contact_person?: string
  email?: string
  phone?: string
  address?: string
  tpin?: string
  credit_limit: number
  credit_days: number
  customer_type: 'retail' | 'wholesale' | 'credit'
  is_active: boolean
  notes?: string
  created_at: string
}

export interface Product {
  id: string
  category_id?: string
  supplier_id?: string
  sku?: string
  barcode?: string
  name: string
  description?: string
  unit_of_measure: string
  cost_price: number
  selling_price: number
  vat_rate: number
  is_vat_inclusive: boolean
  reorder_level: number
  stock_quantity: number
  is_active: boolean
  image_url?: string
  created_at: string
  // joins
  categories?: Category
  suppliers?: Supplier
}

export type InvoiceStatus = 'draft' | 'issued' | 'paid' | 'partial' | 'overdue' | 'cancelled' | 'void'
export type PaymentMethod = 'cash' | 'mobile_money' | 'bank_transfer' | 'cheque' | 'credit' | 'other'

export interface Invoice {
  id: string
  invoice_number: string
  customer_id?: string
  created_by?: string
  invoice_date: string
  due_date?: string
  status: InvoiceStatus
  payment_method?: PaymentMethod
  subtotal: number
  vat_amount: number
  discount_amount: number
  total_amount: number
  amount_paid: number
  balance_due: number
  notes?: string
  created_at: string
  // joins
  customers?: Customer
  profiles?: Profile
}

export interface InvoiceItem {
  id: string
  invoice_id: string
  product_id?: string
  description: string
  quantity: number
  unit_price: number
  discount_pct: number
  vat_rate: number
  vat_amount: number
  line_total: number
  // joins
  products?: Product
}

export type GRNStatus = 'draft' | 'confirmed' | 'cancelled'

export interface StockReceipt {
  id: string
  grn_number: string
  supplier_id?: string
  received_by?: string
  receipt_date: string
  supplier_invoice_ref?: string
  status: GRNStatus
  subtotal: number
  vat_amount: number
  total_amount: number
  notes?: string
  created_at: string
  // joins
  suppliers?: Supplier
  profiles?: Profile
}

export interface StockReceiptItem {
  id: string
  stock_receipt_id: string
  product_id?: string
  description: string
  quantity_ordered: number
  quantity_received: number
  unit_cost: number
  vat_rate: number
  vat_amount: number
  line_total: number
  products?: Product
}

export type DeliveryNoteStatus = 'draft' | 'issued' | 'delivered' | 'cancelled'

export interface DeliveryNote {
  id: string
  dn_number: string
  invoice_id?: string
  customer_id?: string
  issued_by?: string
  delivery_date: string
  status: DeliveryNoteStatus
  delivery_address?: string
  recipient_name?: string
  notes?: string
  created_at: string
  customers?: Customer
  invoices?: Invoice
}

export interface DeliveryNoteItem {
  id: string
  delivery_note_id: string
  product_id?: string
  description: string
  quantity: number
  unit_of_measure: string
  products?: Product
}

export type MovementType = 'sale' | 'purchase' | 'adjustment_in' | 'adjustment_out' | 'return_in' | 'return_out' | 'opening_stock'

export interface StockMovement {
  id: string
  product_id: string
  movement_type: MovementType
  reference_type?: string
  reference_id?: string
  reference_number?: string
  quantity_in: number
  quantity_out: number
  quantity_before: number
  quantity_after: number
  unit_cost?: number
  notes?: string
  created_by?: string
  created_at: string
  products?: Product
  profiles?: Profile
}

// Cart types for POS terminal
export interface CartItem {
  product: Product
  quantity: number
  unit_price: number
  discount_pct: number
  vat_rate: number
  vat_amount: number
  line_total: number
}
