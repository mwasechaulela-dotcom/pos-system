# POS System Architecture

## Overview
This document outlines the architecture of the POS System, which is built using a modern tech stack with React for web, Flutter for mobile, and Supabase as the backend.

## System Architecture
┌─────────────────────────────────────────────────────────────┐
│                    Client Layer                              │
│  ┌──────────────────────┐      ┌──────────────────────┐     │
│  │  React Web App       │      │  Flutter Mobile App  │     │
│  │  (TypeScript/CSS)    │      │  (Dart)              │     │
│  └──────────────────────┘      └──────────────────────┘     │
└─────────────────────────────────────────────────────────────┘
                           │
                    REST/GraphQL API
                           │
┌─────────────────────────────────────────────────────────────┐
│              Supabase Backend Layer                           │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Edge Functions (Serverless)                           │ │
│  │  - Invoice Processing                                 │ │
│  │  - Stock Management                                   │ │
│  │  - Report Generation                                  │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Real-time Features (Supabase Realtime)               │ │
│  │  - Live stock updates                                 │ │
│  │  - Real-time collaboration                            │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Authentication (Supabase Auth)                       │ │
│  │  - JWT-based auth                                     │ │
│  │  - Role-based access control                          │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                           │
┌─────────────────────────────────────────────────────────────┐
│           PostgreSQL Database Layer                           │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Tables:                                               │ │
│  │  - Users, Products, Invoices, Customers              │ │
│  │  - Stock Movements, Receipts, Delivery Notes         │ │
│  │  - Categories, Stock Receipt Items, etc.             │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘